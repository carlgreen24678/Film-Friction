<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>Hall of Shame</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="css/register.css" rel="stylesheet" type="text/css" />
		<link href="css/nav.css" rel="stylesheet" type="text/css" />		
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
	</head>
<body>
	<?php include('header.php');
		  include('fameshame.php');
		  
	 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE WHERE temp_filmaverage > '0' ORDER BY temp_filmaverage ASC LIMIT 10"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$t_filmaverage[$famecount]=$row3["temp_filmaverage"];
					$t_toxic[$famecount]=$row3["temp_toxic"];
					$t_below[$famecount]=$row3["temp_below"];
					$t_average[$famecount]=$row3["temp_average"];
					$t_thumbs[$famecount]=$row3["temp_thumbs"];
					$t_hot[$famecount]=$row3["temp_hot"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover[$famecount]=$row2["cover"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
	
						$famecount ++;
					}					

				}	  

	?>



	<div class="page-title" style="background-color: #00a651">Hall of Shame</div>
	<div class="hall-title">Bottom 10</div>
	
	<!-- 1-3 films -->
	<div class="main-container" style="background-color: rgb(0,166,81,0.2);display: flex;justify-content: center;align-items: center;height: 400px">
			<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[0];
					echo '"><img alt="';
					echo $f_filmname[0];
					echo '" title="';
					echo $f_filmname[0];
					echo '"src="images/films/';
					echo $f_filmcover[0];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[0];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[0]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[0]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[0]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[0]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[0]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[0]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[0]; ?>
			</div>
		</div>
		<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[1];
					echo '"><img alt="';
					echo $f_filmname[1];
					echo '" title="';
					echo $f_filmname[1];
					echo '"src="images/films/';
					echo $f_filmcover[1];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[1];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[1]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[1]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[1]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[1]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[1]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[1]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[1]; ?>
			</div>
		</div>
<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[2];
					echo '"><img alt="';
					echo $f_filmname[2];
					echo '" title="';
					echo $f_filmname[2];
					echo '"src="images/films/';
					echo $f_filmcover[2];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[2];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[2]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[2]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[2]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[2]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[2]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[2]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[2]; ?>
			</div>
		</div>
	</div>
	
	<!-- 4-6 films -->
	<div class="main-container" style="background-color: rgb(0,166,81,0.2);display: flex;justify-content: center;align-items: center;height: 400px">
<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[3];
					echo '"><img alt="';
					echo $f_filmname[3];
					echo '" title="';
					echo $f_filmname[3];
					echo '"src="images/films/';
					echo $f_filmcover[3];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[3];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[3]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[3]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[3]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[3]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[3]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[3]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[3]; ?>
			</div>
		</div>
	<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[4];
					echo '"><img alt="';
					echo $f_filmname[4];
					echo '" title="';
					echo $f_filmname[4];
					echo '"src="images/films/';
					echo $f_filmcover[4];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[4];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[4]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[4]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[4]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[4]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[4]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[4]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[4]; ?>
			</div>
		</div>
<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[5];
					echo '"><img alt="';
					echo $f_filmname[5];
					echo '" title="';
					echo $f_filmname[5];
					echo '"src="images/films/';
					echo $f_filmcover[5];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[5];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[5]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[5]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[5]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[5]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[5]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[5]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[5]; ?>
			</div>
		</div>
	</div>
	
	<!-- 7-9 films -->
	<div class="main-container" style="background-color: rgb(0,166,81,0.2);display: flex;justify-content: center;align-items: center;height: 400px">
	<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[6];
					echo '"><img alt="';
					echo $f_filmname[6];
					echo '" title="';
					echo $f_filmname[6];
					echo '"src="images/films/';
					echo $f_filmcover[6];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[6];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[6]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[6]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[6]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[6]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[6]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[6]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[6]; ?>
			</div>
		</div>
<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[7];
					echo '"><img alt="';
					echo $f_filmname[7];
					echo '" title="';
					echo $f_filmname[7];
					echo '"src="images/films/';
					echo $f_filmcover[7];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[7];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[7]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[7]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[7]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[7]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[7]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[7]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[7]; ?>
			</div>
		</div>
	<div class="hall-container">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[8];
					echo '"><img alt="';
					echo $f_filmname[8];
					echo '" title="';
					echo $f_filmname[8];
					echo '"src="images/films/';
					echo $f_filmcover[8];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[8];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[8]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[8]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[8]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[8]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[8]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[8]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[8]; ?>
			</div>
		</div>		</div>
	</div>
	
	<!-- Film 10 -->
	<div class="main-container" style="background-color: rgb(0,166,81,0.2);display: flex;align-items: center;height: 400px">
		<div class="hall-container" style="margin-left: 4.5%">
			<div class="hall-image">

	<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[9];
					echo '"><img alt="';
					echo $f_filmname[9];
					echo '" title="';
					echo $f_filmname[9];
					echo '"src="images/films/';
					echo $f_filmcover[9];
					echo '"style="height: 100%; margin-left:20%;"></a>"';
					}else {
					echo '<img alt="" title=""';
					echo 'src="images/films/';
					echo $f_filmcover[9];
					echo '"style="height: 100%; margin-left:20%;">>';
					}
				?>						
				
				
				
			</div>
			<div class="hall-film-title">
			<?php echo $f_filmname[9]; ?>
			</div>
			<div class="hall-rating" style="margin-left:5%">
				<img class="hall-rating-img" alt="" src="images/rate one.png">
				<p class="hall-rating-num">
					<?php echo $t_toxic[9]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate two.png">
				<p class="hall-rating-num">
					<?php echo $t_below[9]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate three.png">
				<p class="hall-rating-num">
					<?php echo $t_average[9]; ?>
				</p>
			</div>
			<div class="hall-rating">
				<img class="hall-rating-img" alt="" src="images/rate four.png">
				<p class="hall-rating-num">
				<?php echo $t_thumbs[9]; ?>
				</p>
			</div>
			<div class="hall-rating" style="margin-right: 5%">
				<img class="hall-rating-img" alt="" src="images/rate five.png">
				<p class="hall-rating-num">
					<?php echo $t_hot[9]; ?>
				</p>
			</div>
			<div class="hall-avg-rating">
				Average Rating: <?php echo $t_filmaverage[9]; ?>
			</div>
		</div>
	</div>
	<?php include('footer.php');
$drp1 = "DROP  TABLE IF EXISTS TEMP_FAMESHAME_TABLE";
     mysql_query($drp1 ) or ( "Error " . mysql_error () ) ; 	


	?>
</body>
</html>