<?php
session_start();
$userflag = 0;

 if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$storeuser = $_SESSION['userID'];
	$userflag = 1;
	} 
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>New and Trending</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="css/register.css" rel="stylesheet" type="text/css" />
		<link href="css/nav.css" rel="stylesheet" type="text/css" />				
		<link href="css/film.css" rel="stylesheet" type="text/css" />			
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
		
		
		
		
		
	</head>
<body>
	<?php include('header.php');
		  include('fameshame.php');
	 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE ORDER BY RAND() LIMIT 4"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$t_filmaverage[$famecount]=$row3["temp_filmaverage"];
					$t_toxic[$famecount]=$row3["temp_toxic"];
					$t_below[$famecount]=$row3["temp_below"];
					$t_average[$famecount]=$row3["temp_average"];
					$t_thumbs[$famecount]=$row3["temp_thumbs"];
					$t_hot[$famecount]=$row3["temp_hot"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover[$famecount]=$row2["cover"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
						$f_filmdescription[$famecount]=$row2["description"];
						$f_filmbackground[$famecount]=$row2["background"];
						$f_filmvideo[$famecount]=$row2["video"];
							$favourited[$famecount] = 0;		

							require_once "conninc.php";
									$q2 = "SELECT * FROM filmfavourite WHERE userid = '$storeuser' && filmid = '$f_filmid[$famecount]' ORDER BY id LIMIT 1";
									$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
									while($row2=mysql_fetch_array($r2)) {
										$favourited[$famecount] = 1;
									}						
						$famecount ++;
					
					
					}					

				}	 		  

	$t_toxic[0] = 0;
	$t_toxic[1] = 0;
	$t_toxic[2] = 0;
	$t_toxic[3] = 0;
	$t_below[0] = 0;
	$t_below[1] = 0;
	$t_below[2] = 0;
	$t_below[3] = 0;
	$t_average[0] = 0;
	$t_average[1] = 0;
	$t_average[2] = 0;
	$t_average[3] = 0;	
	$t_thumbs[0] = 0;
	$t_thumbs[1] = 0;
	$t_thumbs[2] = 0;
	$t_thumbs[3] = 0;
	$t_hot[0] = 0;
	$t_hot[1] = 0;
	$t_hot[2] = 0;
	$t_hot[3] = 0;
	?>
						
	<div class="page-title">New and Trending</div>
	<!-- First Film Container --> 
	<div class="main-container" style="display: flex;justify-content: center;align-items: center; height: 450px">
		<div class="trend-container">
			<div class="trendimgrating-container">
				<a href="film.php?f=<?php echo $f_filmid[0];?>">
				<img class="trendimg" alt="" src="images/filmbackground/<?php echo $f_filmbackground[0]; ?>"></a>
				<div class="trendrating" style="height:45%;">
				
					<div class="rating">
						<img class="ff-rating" alt="Toxic Ratings" src="images/rate one.png">
						<p class="ff-rating-num">
							<?php echo $t_toxic[0]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Below Par Ratings" src="images/rate two.png">
						<p class="ff-rating-num">
							<?php echo $t_below[0]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Average Ratings" src="images/rate three.png">
						<p class="ff-rating-num">
							<?php echo $t_average[0]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Thumbs Up Ratings" src="images/rate four.png">
						<p class="ff-rating-num">
							<?php echo $t_thumbs[0]; ?>
						</p>
					</div>
					<div class="rating" style="margin-right: 0;">
						<img class="ff-rating" alt="Hot Stuff Ratings" src="images/rate five.png">
						<p class="ff-rating-num">
							<?php echo $t_hot[0]; ?>
						</p>
					</div>
				</div>
			</div>
			<div class="trendinfo-conatiner">
				<div class="trend-title">
					<?php echo $f_filmname[0] ?>
				</div>
				
				<div class="trend-info">
					<p class="trendinfo-text">
						<?php echo $f_filmdescription[0] ?>
					</p>
				</div>
				<div class="trend-options"style="width:70%;">
				<?php $film_video = $f_filmvideo[0]; ?>


				<div class ="film_btn_hlder">
						<button onclick="sharealerta()" class = "share_button" style="cursor: pointer; height:100%;"   alt="Share this fan edit on social media" title="Share this fan edit on social media" >
					</button>		
				</div>
	<?php				
		if($userflag == 1){	
			if($favourited[0] == 0) {	?>			
					<div class ="film_btn_hlder">
						<button onclick="addfavouritea()" class = "favourite_button" style="cursor: pointer; height:100%;"   alt="Add to favourites" title="Add to favourites" >
					</button>
					</div>					
	<?php		}else { ?>
					<div class ="film_btn_hlder">
						<button onclick="delfavouritea()" class = "unfavourite_button" style="cursor: pointer; height:100%;"   alt="Remove from favourites" title="Remove from favourites" >
					</button>
					</div>					
	<?php		}
			}
	?>			

				</div>
				
			</div>
		</div>
	</div>
	
	<!-- Second Film Container -->
	<div class="main-container" style="display: flex;justify-content: center;align-items: center; height: 450px">
			<div class="trendinfo-conatiner" style="margin-left: 0; margin-right: 2.5%">
				<div class="trend-title">
					<?php echo $f_filmname[1] ?>
				</div>
				
				<div class="trend-info">
					<p class="trendinfo-text">
						<?php echo $f_filmdescription[1] ?>
					</p>
				</div>
				<div class="trend-options"style="width:70%;">
				<?php $film_video = $f_filmvideo[1]; ?>


				<div class ="film_btn_hlder">
						<button onclick="sharealertb()" class = "share_button" style="cursor: pointer; height:100%;"   alt="Share this fan edit on social media" title="Share this fan edit on social media" >
					</button>		
				</div>
	<?php				
		if($userflag == 1){	
			if($favourited[1] == 0) {	?>			
					<div class ="film_btn_hlder">
						<button onclick="addfavouriteb()" class = "favourite_button" style="cursor: pointer; height:100%;"   alt="Add to favourites" title="Add to favourites" >
					</button>
					</div>					
	<?php		}else { ?>
					<div class ="film_btn_hlder">
						<button onclick="delfavouriteb()" class = "unfavourite_button" style="cursor: pointer; height:100%;"   alt="Remove from favourites" title="Remove from favourites" >
					</button>
					</div>					
	<?php		}
			}
	?>			

				</div>
				
			</div>
			<div class="trendimgrating-container">
				<a href="film.php?f=<?php echo $f_filmid[1];?>">
				<img class="trendimg" alt="" src="images/filmbackground/<?php echo $f_filmbackground[1]; ?>"></a>
				<div class="trendrating" style="height:45%;">
				
					<div class="rating">
						<img class="ff-rating" alt="Toxic Ratings" src="images/rate one.png">
						<p class="ff-rating-num">
							<?php echo $t_toxic[1]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Below Par Ratings" src="images/rate two.png">
						<p class="ff-rating-num">
							<?php echo $t_below[1]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Average Ratings" src="images/rate three.png">
						<p class="ff-rating-num">
							<?php echo $t_average[1]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Thumbs Up Ratings" src="images/rate four.png">
						<p class="ff-rating-num">
							<?php echo $t_thumbs[1]; ?>
						</p>
					</div>
					<div class="rating" style="margin-right: 0;">
						<img class="ff-rating" alt="Hot Stuff Ratings" src="images/rate five.png">
						<p class="ff-rating-num">
							<?php echo $t_hot[1]; ?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<!-- Third Film Container -->
	<div class="main-container" style="display: flex;justify-content: center;align-items: center; height: 450px">
		<div class="trend-container">
			<div class="trendimgrating-container">
				<a href="film.php?f=<?php echo $f_filmid[2];?>">
				<img class="trendimg" alt="" src="images/filmbackground/<?php echo $f_filmbackground[2]; ?>"></a>
				<div class="trendrating" style="height:45%;">
				
					<div class="rating">
						<img class="ff-rating" alt="Toxic Ratings" src="images/rate one.png">
						<p class="ff-rating-num">
							<?php echo $t_toxic[2]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Below Par Ratings" src="images/rate two.png">
						<p class="ff-rating-num">
							<?php echo $t_below[2]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Average Ratings" src="images/rate three.png">
						<p class="ff-rating-num">
							<?php echo $t_average[2]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Thumbs Up Ratings" src="images/rate four.png">
						<p class="ff-rating-num">
							<?php echo $t_thumbs[2]; ?>
						</p>
					</div>
					<div class="rating" style="margin-right: 0;">
						<img class="ff-rating" alt="Hot Stuff Ratings" src="images/rate five.png">
						<p class="ff-rating-num">
							<?php echo $t_hot[2]; ?>
						</p>
					</div>
				</div>
			</div>
			<div class="trendinfo-conatiner">
				<div class="trend-title">
					<?php echo $f_filmname[2] ?>
				</div>
				
				<div class="trend-info">
					<p class="trendinfo-text">
						<?php echo $f_filmdescription[2] ?>
					</p>
				</div>
				<div class="trend-options"style="width:70%;">
				<?php $film_video = $f_filmvideo[2]; ?>


				<div class ="film_btn_hlder">
						<button onclick="sharealertc()" class = "share_button" style="cursor: pointer; height:100%;"   alt="Share this fan edit on social media" title="Share this fan edit on social media" >
					</button>		
				</div>
	<?php				
		if($userflag == 1){	
			if($favourited[2] == 0) {	?>			
					<div class ="film_btn_hlder">
						<button onclick="addfavouritec()" class = "favourite_button" style="cursor: pointer; height:100%;"   alt="Add to favourites" title="Add to favourites" >
					</button>
					</div>					
	<?php		}else { ?>
					<div class ="film_btn_hlder">
						<button onclick="delfavouritec()" class = "unfavourite_button" style="cursor: pointer; height:100%;"   alt="Remove from favourites" title="Remove from favourites" >
					</button>
					</div>					
	<?php		}
			}
	?>			

				</div>
				
			</div>
		</div>
	</div>
	
	
	<!-- Fourth Film Container -->
	<div class="main-container" style="display: flex;justify-content: center;align-items: center; height: 450px">
			<div class="trendinfo-conatiner" style="margin-left: 0; margin-right: 2.5%">
				<div class="trend-title">
					<?php echo $f_filmname[3] ?>
				</div>
				
				<div class="trend-info">
					<p class="trendinfo-text">
						<?php echo $f_filmdescription[3] ?>
					</p>
				</div>
				<div class="trend-options"style="width:70%;">
				<?php $film_video = $f_filmvideo[3]; ?>


				<div class ="film_btn_hlder">
						<button onclick="sharealertd()" class = "share_button" style="cursor: pointer; height:100%;"   alt="Share this fan edit on social media" title="Share this fan edit on social media" >
					</button>		
				</div>
	<?php				
		if($userflag == 1){	
			if($favourited[3] == 0) {	?>			
					<div class ="film_btn_hlder">
						<button onclick="addfavourited()" class = "favourite_button" style="cursor: pointer; height:100%;"   alt="Add to favourites" title="Add to favourites" >
					</button>
					</div>					
	<?php		}else { ?>
					<div class ="film_btn_hlder">
						<button onclick="delfavourited()" class = "unfavourite_button" style="cursor: pointer; height:100%;"   alt="Remove from favourites" title="Remove from favourites" >
					</button>
					</div>					
	<?php		}
			}
	?>			

				</div>
				
			</div>
			<div class="trendimgrating-container">
				<a href="film.php?f=<?php echo $f_filmid[3];?>">
				<img class="trendimg" alt="" src="images/filmbackground/<?php echo $f_filmbackground[3]; ?>"></a>
				<div class="trendrating" style="height:45%;">
				
					<div class="rating">
						<img class="ff-rating" alt="Toxic Ratings" src="images/rate one.png">
						<p class="ff-rating-num">
							<?php echo $t_toxic[3]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Below Par Ratings" src="images/rate two.png">
						<p class="ff-rating-num">
							<?php echo $t_below[3]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Average Ratings" src="images/rate three.png">
						<p class="ff-rating-num">
							<?php echo $t_average[3]; ?>
						</p>
					</div>
					<div class="rating">
						<img class="ff-rating" alt="Thumbs Up Ratings" src="images/rate four.png">
						<p class="ff-rating-num">
							<?php echo $t_thumbs[3]; ?>
						</p>
					</div>
					<div class="rating" style="margin-right: 0;">
						<img class="ff-rating" alt="Hot Stuff Ratings" src="images/rate five.png">
						<p class="ff-rating-num">
							<?php echo $t_hot[3]; ?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	<?php include('footer.php');
	$drp1 = "DROP  TABLE IF EXISTS TEMP_FAMESHAME_TABLE";
     mysql_query($drp1 ) or ( "Error " . mysql_error () ) ; 	



	?>

	<!---- scripts for film 1 --->
	<script>
		function sharealerta() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for sharing a film trailer please copy the link provided:            " + filmlink);
		}
		</script>							
		<script type="text/javascript">
					function addfavouritea(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $f_filmid[0] ?>";	
					var filmname = "<?php echo $f_filmname[0] ?>";	
					var filmfav = confirm("Add the following film to favourites?\n" + filmname);
					if (filmfav == true) {
					  window.location = "addfav.php?us=" + userid + "&fm=" + filmid;
					} else {

					}
					}
		</script>
			
	<script type="text/javascript">
					function delfavouritea(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $f_filmid[0] ?>";	
					var filmname = "<?php echo $f_filmname[0] ?>";	
					var filmfav = confirm("Remove the following film from favourites?\n" + filmname);
					if (filmfav == true) {
					  window.location = "delfav.php?us=" + userid + "&fm=" + filmid;
					} else {

					}
					}
		</script>							
<!---- scripts for film 2 --->
	<script>
		function sharealertb() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for sharing a film trailer please copy the link provided:            " + filmlink);
		}
		</script>							
		<script type="text/javascript">
					function addfavouriteb(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $f_filmid[1] ?>";	
					var filmname = "<?php echo $f_filmname[1] ?>";	
					var filmfav = confirm("Add the following film to favourites?\n" + filmname);
					if (filmfav == true) {
					  window.location = "addfav.php?us=" + userid + "&fm=" + filmid;
					} else {

					}
					}
		</script>
			
	<script type="text/javascript">
					function delfavouriteb(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $f_filmid[1] ?>";	
					var filmname = "<?php echo $f_filmname[1] ?>";	
					var filmfav = confirm("Remove the following film from favourites?\n" + filmname);
					if (filmfav == true) {
					  window.location = "delfav.php?us=" + userid + "&fm=" + filmid;
					} else {

					}
					}
		</script>				
	
</body>
</html>