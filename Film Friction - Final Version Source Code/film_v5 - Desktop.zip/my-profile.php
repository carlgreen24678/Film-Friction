<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
    $userid = $_SESSION['userID'];
	$userflag = 1;
	} 
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>My Profile</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="css/profile.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>


<script>
function editname() {
  var txt;
  var person = prompt("Please enter your name:");
  var userid = "<?php echo $userid ?>";	
  if (person == null || person == "") {
    txt = "User cancelled the prompt.";
  } else {
	window.location = "editname.php?us=" + userid + "&name=" + person;  
  }
}
</script>	

	</head>

<body>
	
	
	
	<?php include('header.php');
	  include('getuser.php');
	
	?>
	<div class="page-title">My Profile</div>
	<div class="main-container" style="justify-content: center;align-items: center; height: auto; padding-top: 5px">
		<div class="profile-container">
			<div class="profile-img" style="width:35%;">
				<div class="img-holder">	
					<?php echo "<img src='images/profile/$avatar' height='80%' alt='' style='margin-left:20px; margin-top:20px;'/>"; ?>
				</div>
				
				<div class="img-button">				
				<form action="upload.php" method="post" enctype="multipart/form-data">  
				<input type="file" name="uploadedfile" class="photo_button" accept="image/*" capture >
				<input type="hidden" id="avid" name="avid" value="<?php echo $userid?>">			
				<input type="submit" class="submit_button" value="Upload">
				</div>
				</form>				
			</div>

			<div class="profile-info">
				<div class="profile-name">
					<?php echo $name . "  "; ?> <button onclick="editname()" style="margin-left:50px;">Edit name</button>
				</div>
				<div class="profile-bio">
				<form action="writebio.php" method="get">
					<textarea name='bio' rows='15' class=''><?php echo $bio; ?></textarea></td>
					  <input type="hidden" id="useid" name="useid" value="<?php echo $userid?>">
					<input type="submit" class = "biosubmit" style="cursor: pointer;" value="Update Bio">
				</form>	
					

					
					
	 			
					
				<div data-role="content">
   
  </div>
				
				
				
				
				</div>
			</div>
		</div>
		<div class="profile-container" style="display: inline-block; margin-top: 0">
				<div class="profile-nav">
					<button class="profile-btn">Subscriptions</button>
					<button class="profile-btn">Playlist</button>
					<button class="profile-btn">History</button>
				</div>
				<div class="nav-content">

				</div>
			</div>
			
		 
	</div>
	<?php include('footer.php') ?>
</body>
</html>