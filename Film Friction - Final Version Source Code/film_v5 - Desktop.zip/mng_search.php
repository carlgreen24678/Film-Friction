<?php


include "conninc.php"; 

$q1 = "SELECT * FROM films WHERE name LIKE '%{$_GET['term']}%'";

$results = mysql_query($q1);

$mainarray = array(); // holding array for product information

while ($row=mysql_fetch_array($results)) {

		$rowarray = array (
			"id" => $row['id'],
			"label" => $row['name']	
			); // array holding row details
			array_push($mainarray,$rowarray); // add row to holding array
}
echo json_encode($mainarray); //output the results to the search box

?>