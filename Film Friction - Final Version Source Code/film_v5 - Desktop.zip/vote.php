<?php
		$store_user = $_REQUEST['us'];
		$store_film = $_REQUEST['fm'];
		$store_vote = $_REQUEST['vt'];
		$vote_exist = 0;
		require_once "conninc.php";

		$q2 = "SELECT * FROM vote WHERE userid = '$store_user' && filmid = '$store_film' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
			$vote_exist = 1;			
			}
		if ($vote_exist == 0) {
			
		require_once "conninc.php";
		$q3 = "INSERT INTO vote (userid, filmid, vote) VALUES ('$store_user', '$store_film', '$store_vote')";       		
			  $r3 = mysql_query($q3);
			echo mysql_error();
		}
		else {
		require_once "conninc.php";
		$q3 = "UPDATE vote set vote = '{$store_vote}' WHERE userid = '$store_user' AND filmid = '$store_film'";       		
			  $r3 = mysql_query($q3);
			echo mysql_error();			
		}
		header('Location: film.php?f='.$store_film.'#filmratings-container');	

?>
