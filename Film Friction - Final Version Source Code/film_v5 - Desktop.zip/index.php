<?php
session_start();
$userflag = 0;

 if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
	$store_subs = $_REQUEST['un'];
	$store_favs = $_REQUEST['fv'];
	
	?>


<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>Film Friction</title>

		<link href="css/tchat.css" rel="stylesheet" type="text/css" />
		<link href="css/fchat.css" rel="stylesheet" type="text/css" />
		<link href="css/schat.css" rel="stylesheet" type="text/css" />
		<link href="css/cchat.css" rel="stylesheet" type="text/css" />
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="css/register.css" rel="stylesheet" type="text/css" />
		<link href="css/nav.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script src="js/tchat.js"></script>
		<script src="js/fchat.js"></script>
		<script src="js/schat.js"></script>
		<script src="js/cchat.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
		
			<script type="text/javascript">
					function trendsub(){
					var trsubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (trsubbal != null) {
						alert("Thank you for subscribing to New and Trending please check email address: " + trsubbal);
						window.location = "trndsub.php?em=" + trsubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
			</script>
			<script type="text/javascript">
					function famesub(){
					var famesubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (famesubbal != null) {
						alert("Thank you for subscribing to Hall of Fame please check email address: " + famesubbal);
						window.location = "famesub.php?em=" + famesubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
 
 
			 
			</script>
		<script type="text/javascript">
					function shamesub(){
					var shamesubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (shamesubbal != null) {
						alert("Thank you for subscribing to Hall of Shame please check email address: " + shamesubbal);
						window.location = "shamesub.php?em=" + shamesubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
 
 
			 
			</script>	
		<script type="text/javascript">
					function comingsub(){
					var comingsubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (comingsubbal != null) {
						alert("Thank you for subscribing to Coming Soon please check email address: " + comingsubbal);
						window.location = "comingsub.php?em=" + comingsubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
 
 
			 
			</script>	

<script src="js/redirection-mobile.js"></script>
			<script>
				SA.redirection_mobile({
				tablet_redirection : "true",
				tablet_host : "t.filmfriction.com",
				tablet_prefix : "http"
				});
			</script>		
					
	</head>

	<body>
		<?php 
		include('fameshame.php');
		include('header.php');	
			require_once "conninc.php";
			$count=0;
			$q2 = "SELECT * FROM films ORDER BY RAND() LIMIT 6";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {
				$filmcover[$count]=$row2["cover"];
				$filmid[$count]=$row2["id"];
				$filmname[$count]=$row2["name"];
				$count ++;
			}	

	?>	
	
		<!-- New & Trending --> 
		<div class="main-container">
			<div class="container1-lr">
				<div class="div1">
					<div class="index-title">New and Trending</div>
				<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[0];
					echo '"><img alt="';
					echo $filmname[0];
					echo '" title="';
					echo $filmname[0];
					echo '"src="images/films/';
					echo $filmcover[0];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/films/';
					echo $filmcover[0];
					echo '">';
					}
				?>	
					
					
				</div>
			</div>
			<div class="container2-lr">
				<div class="div2">
				<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[1];
					echo '"><img alt="';
					echo $filmname[1];
					echo '" title="';
					echo $filmname[1];
					echo '"src="images/films/';
					echo $filmcover[1];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $filmcover[1];
					echo '">';
					}
				?>
				</div>
				<div class="div3">
					<a href="rss-feeds.php"><img alt="New and Trending RSS Feed" src="images/rss-btn.png"></a>
				</div>
			</div>
			<div class="container3-lr">
				<div class="div4">
					<button onclick="trendsub()"><img alt="New and Trending Channel Subscribe Button" src="images/sub-btn.png" style="cursor: pointer;" alt="Subscribe to New and Trending" title="Subscribe to New and Trending"></button>
				</div>
				<div class="div5">
				<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[2];
					echo '"><img alt="';
					echo $filmname[2];
					echo '" title="';
					echo $filmname[2];
					echo '"src="images/films/';
					echo $filmcover[2];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $filmcover[2];
					echo '">';
					}
				?>				
				</div>
			</div>
			<div class="container4-lr">
				<div class="div6">
					<div class="chat-title">Chat Feed</div>
					
	 		<?php include ('t_chat.php');	?>		 
						
				</div>
			</div>
		</div>
		
		
		<!-- Hall of Fame -->
<?php 		 
		 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE ORDER BY temp_filmaverage DESC LIMIT 3"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover[$famecount]=$row2["cover"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
						$famecount ++;
					}					

				}

?>		
		
		<div class="main-container">
			<div class="container1-rl">
				<div class="div6">
					<div class="chat-title">Chat Feed</div>
				<?php include ('f_chat.php');	?>	
				</div>
			</div>
			<div class="container2-rl">
				<div class="div4">
					<button onclick="famesub()"><img alt="Hall of Fame Channel Subscribe Button" src="images/sub-btn.png" style="cursor: pointer;" alt="Subscribe to Hall of Fame" title="Subscribe to Hall of Fame"></button>
				</div>
				<div class="div5">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[2];
					echo '"><img alt="';
					echo $f_filmname[2];
					echo '" title="';
					echo $f_filmname[2];
					echo '"src="images/films/';
					echo $f_filmcover[2];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $f_filmcover[2];
					echo '">';
					}
				?>			
				</div>
			</div>
			<div class="container3-rl">
				<div class="div2">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[1];
					echo '"><img alt="';
					echo $f_filmname[1];
					echo '" title="';
					echo $f_filmname[1];
					echo '"src="images/films/';
					echo $f_filmcover[1];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $f_filmcover[1];
					echo '">';
					}
				?>
				</div>
				<div class="div3">
					<a href="rss-feeds.php"><img alt="Hall of Fame RSS Feed" src="images/rss-btn.png"></a>
				</div>
			</div>
			<div class="container4-rl">
				<div class="div1">
					<div class="index-title">Hall of Fame</div>
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[0];
					echo '"><img alt="';
					echo $f_filmname[0];
					echo '" title="';
					echo $f_filmname[0];
					echo '"src="images/films/';
					echo $f_filmcover[0];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $f_filmcover[0];
					echo '">';
					}
				?>	
				</div>
			</div>
		</div>
		</div>
		
		
		
		
		
		<!-- Hall of Shame -->
<?php 		 
		 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE ORDER BY temp_filmaverage ASC LIMIT 3"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover[$famecount]=$row2["cover"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
						$famecount ++;
					}					

				}

?>		
		<div class="main-container">
			<div class="container1-lr">
				<div class="div1">
					<div class="index-title">Hall of Shame</div>
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[0];
					echo '"><img alt="';
					echo $f_filmname[0];
					echo '" title="';
					echo $f_filmname[0];
					echo '"src="images/films/';
					echo $f_filmcover[0];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $f_filmcover[0];
					echo '">';
					}
				?>	
				</div>
			</div>
			<div class="container2-lr">
				<div class="div2">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[1];
					echo '"><img alt="';
					echo $f_filmname[1];
					echo '" title="';
					echo $f_filmname[1];
					echo '"src="images/films/';
					echo $f_filmcover[1];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $f_filmcover[1];
					echo '">';
					}
				?>				
				
				</div>
				<div class="div3">
					<a href="rss-feeds.php"><img alt="Hall of Shame RSS Feed" src="images/rss-btn.png"></a>
				</div>
			</div>
			<div class="container3-lr">
				<div class="div4">
					<button onclick="shamesub()"><img alt="Hall of Shame Channel Subscribe Button" src="images/sub-btn.png" style="cursor: pointer;" alt="Subscribe to Hall of Shame" title="Subscribe to Hall of Shame"></button>
				</div>
				<div class="div5">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $f_filmid[2];
					echo '"><img alt="';
					echo $f_filmname[2];
					echo '" title="';
					echo $f_filmname[2];
					echo '"src="images/films/';
					echo $f_filmcover[2];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $f_filmcover[2];
					echo '">';
					}
				?>						
				</div>
			</div>
			<div class="container4-lr">
				<div class="div6">
					<div class="chat-title">Chat Feed</div>
					 <?php include ('s_chat.php');	?>		
				</div>
			</div>
		</div>
		</div>
		
		
		<!-- Coming Soon -->
		<div class="main-container">
			<div class="container1-rl">
				<div class="div6">
					<div class="chat-title">Chat Feed</div>
			<?php include ('c_chat.php');	?>	
				</div>
			</div>
			<div class="container2-rl">
				<div class="div4">
					<button onclick="comingsub()"><img alt="Coming Soon Channel Subscribe Button" src="images/sub-btn.png" style="cursor: pointer;" alt="Subscribe to Coming Soon Channel" title="Subscribe to Coming Soon Channel"></button>
				</div>
				<div class="div5">
				<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[3];
					echo '"><img alt="';
					echo $filmname[3];
					echo '" title="';
					echo $filmname[3];
					echo '"src="images/films/';
					echo $filmcover[3];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $filmcover[3];
					echo '">';
					}
				?>				
				</div>
			</div>
			<div class="container3-rl">
				<div class="div2">
				<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[4];
					echo '"><img alt="';
					echo $filmname[4];
					echo '" title="';
					echo $filmname[4];
					echo '"src="images/films/';
					echo $filmcover[4];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $filmcover[4];
					echo '">';
					}
				?>				
				</div>
				<div class="div3">
					<a href="rss-feeds.php"><img alt="Coming Soon RSS Feed" src="images/rss-btn.png"></a>
				</div>
			</div>
			<div class="container4-rl">
				<div class="div1">
					<div class="index-title">Coming Soon</div>
				<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[5];
					echo '"><img alt="';
					echo $filmname[5];
					echo '" title="';
					echo $filmname[5];
					echo '"src="images/films/';
					echo $filmcover[5];
					echo '"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo 'src="images/films/';
					echo $filmcover[5];
					echo '">';
					}
				?>				
				</div>
			</div>
		</div>
		</div>
		
		<?php include('footer.php') ;
		
	if ($store_subs == 2) {
		echo "<script>";
		echo "alert('You have successfully unsubscribed');";
		echo "</script>";
		}	
	if ($store_favs == 2) {
		echo "<script>";
		echo "alert('Film added to favourites');";
		echo "</script>";
		}	
 	$drp1 = "DROP  TABLE IF EXISTS TEMP_FAMESHAME_TABLE";
     mysql_query($drp1 ) or ( "Error " . mysql_error () ) ; 		
		
		?>
		
		
	</body>
</html>
