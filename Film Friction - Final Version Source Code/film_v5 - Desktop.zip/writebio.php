<?php
	$bio = $_GET["bio"];
	$user = $_GET["useid"];
		require_once "conninc.php";
		$q4 = "UPDATE `user` SET `bio` = '$bio'  WHERE `user`.`id` = '$user'";
					$r4 = mysql_query($q4);
					echo mysql_error();		
 
 		header('Location: my-profile.php');	

?>
