<?php
include "conninc.php"; 
		$temp_table_create = "CREATE  TABLE IF NOT EXISTS `TEMP_FAMESHAME_TABLE` (
          `temp_id` bigint(20) NOT NULL auto_increment,
          `temp_filmid` int(10),
          `temp_filmtotal` int(10),
          `temp_filmcount` int(10),
		  `temp_filmaverage` int(10),
          `temp_toxic` int(10),
          `temp_below` int(10),
          `temp_average` int(10),
          `temp_thumbs` int(10),
          `temp_hot` int(10),
		  PRIMARY KEY (`temp_id`)
          ) ENGINE=MEMORY DEFAULT CHARSET=latin1";

mysql_query($temp_table_create)or die (mysql_errno()."<br/>".mysql_error()); 
		
$q4 = "SELECT * FROM films ORDER BY id ASC";		 
			$r4 = mysql_query($q4)or die($myQuery."<br/><br/>".mysql_error());
			while($row4=mysql_fetch_array($r4)) {		
			$ffilm_id=$row4["id"];
			$q5 = "INSERT INTO TEMP_FAMESHAME_TABLE (temp_filmid) VALUES ('$ffilm_id')";       		
			$r5 = mysql_query($q5);
			echo mysql_error();
		}

		$q2 = "SELECT * FROM vote  ORDER BY id DESC";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
			$film_id=$row2["filmid"];
			$vote_id=$row2["vote"];
			$filmcount = 1;
			$record_exist = 0;
				
				$filmtotal = 0;
				$filmtoxic = 0;
				$filmbelow = 0;
				$filmaverage = 0;
				$filmthumbs = 0;
				$filmhot = 0;	
		
		$q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE WHERE temp_filmid = '$film_id' ORDER BY temp_id LIMIT 1"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
			while($row3=mysql_fetch_array($r3)) {				
				$record_exist = 1;
				$filmcount = $row3["temp_filmcount"];
				$filmtotal = $row3["temp_filmtotal"];
				$filmtoxic = $row3["temp_toxic"];
				$filmbelow = $row3["temp_below"];
				$filmaverage = $row3["temp_average"];
				$filmthumbs = $row3["temp_thumbs"];
				$filmhot = $row3["temp_hot"];
				$filmcount = $filmcount + 1;
			if ($vote_id == 1) {$filmtoxic = $filmtoxic + 1; }
			if ($vote_id == 2) {$filmbelow = $filmbelow + 1; }
			if ($vote_id == 3) {$filmaverage = $filmaverage + 1; }
			if ($vote_id == 4) {$filmthumbs = $filmthumbs + 1; }
			if ($vote_id == 5) {$filmhot = $filmhot + 1; }
				
				$filmtotal = $filmtotal + $vote_id;
				$vote_average = ceil($filmtotal / $filmcount);
			}	
		if ($record_exist == 0) {
			if ($vote_id == 1) {$filmtoxic =  1; }
			if ($vote_id == 1) {$vote_average =  $vote_id; }
			if ($vote_id == 2) {$filmbelow =  1; }
			if ($vote_id == 2) {$vote_average =  $vote_id; }
			if ($vote_id == 3) {$filmaverage = 1; }
			if ($vote_id == 3) {$vote_average = $vote_id; }
			if ($vote_id == 4) {$filmthumbs = 1; }
			if ($vote_id == 4) {$vote_average = $vote_id; }
			if ($vote_id == 5) {$filmhot = 1; }		
			if ($vote_id == 5) {$vote_average = $vote_id; }		
 
		$q3 = "INSERT INTO TEMP_FAMESHAME_TABLE (temp_filmid, temp_filmcount, temp_filmtotal, temp_filmaverage, temp_toxic, temp_below, temp_average, temp_thumbs, temp_hot) VALUES ('$film_id', '$filmcount', '$vote_id', '$vote_average', '$filmtoxic', '$filmbelow', '$filmaverage', '$filmthumbs', '$filmhot')";       		
 
			$r3 = mysql_query($q3);
			echo mysql_error();
			
		}
		else {
 
		$q3 = "UPDATE TEMP_FAMESHAME_TABLE set temp_filmcount = '{$filmcount}', temp_filmtotal = '{$filmtotal}', temp_filmaverage = '{$vote_average}', temp_average = '{$vote_average}', temp_toxic = '{$filmtoxic}', temp_below = '{$filmbelow}', temp_average = '{$filmaverage}', temp_thumbs = '{$filmthumbs}', temp_hot = '{$filmhot}'  WHERE temp_filmid = '$film_id'";       		
 			  					
			  $r3 = mysql_query($q3);
			echo mysql_error();
			
		}
}
		
		
		
		
		

?>
