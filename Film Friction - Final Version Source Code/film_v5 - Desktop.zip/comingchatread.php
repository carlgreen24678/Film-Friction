<?php
require_once "conninc.php";

	$q2 = "SELECT * FROM comingchat ORDER BY id ASC";
	 
	$r2 = mysql_query($q2)or die($q2."<br/><br/>".mysql_error());
	while($row2=mysql_fetch_array($r2)) {
        $c_username=$row2["username"];
        $c_text=$row2["text"];
        $c_time=date('G:i', strtotime($row2["time"])); //outputs date as # #Hour#:#Minute#;

        echo "<p>$c_username: $c_text</p>\n";
    }

?>