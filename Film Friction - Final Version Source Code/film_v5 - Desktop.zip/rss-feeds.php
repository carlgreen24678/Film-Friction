<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
?>


<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>RSS Feeds</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="css/register.css" rel="stylesheet" type="text/css" />
		<link href="css/nav.css" rel="stylesheet" type="text/css" />		
		<link href="css/rss.css" rel="stylesheet" type="text/css" />		
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
		<script>
		function sharefanedit() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for linking to the New XML file please copy the link provided: https://forums.fanedit.org/syndication.php?fid=&type=atom1.0&limit=15           ");
		}
		</script>
		<script>
		function sharefame() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for linking to the Hall of fame XML file please copy the link provided: http://www.filmfriction.com/hallfame.xml            ");
		}
		</script>
		<script>
		function shareshame() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for linking to the Hall of shame XML file please copy the link provided: http://www.filmfriction.com/hallshame.xml            ");
		}
		</script>	
		<script>
		function shareupncoming() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for linking to the Up n Coming XML file please copy the link provided: http://www.filmfriction.com/upncoming.xml            ");
		}
		</script>			
	</head>
<body>
	<?php 
	include('header.php');

	include('famexmlcreate.php');
	include('shamexmlcreate.php');
	include('upxmlcreate.php');


	?>
	<div class="page-title">RSS Feeds</div>
	<div class="main-container" style="display: flex;justify-content: center;align-items: center; height: auto">
		<div class="rss-main-container">
			<!-- New and Trending RSS -->
			<div class="rss-container">
				<div class="rss-title">New and Trending</div>
				<div class="rss-content">
<?php
include('atomgrab.php') ?>			
				
				</div>
			
<button onclick="sharefanedit()" class="fanedit styled" type="button">New XML Link</button>
			
			</div>
	
			<!-- Hall of Fame RSS -->
			<div class="rss-container">
				<div class="rss-title">Hall of Fame</div>
				<div class="rss-content">
<?php
			$get = file_get_contents('hallfame.xml');
			$arr = simplexml_load_string($get);
			 $y=0;
			 $x = 10;
			while ($y<=$x){
			 	 $cover=$arr->hallfame[$y]->cover;
			 	 $title=$arr->hallfame[$y]->name;
				 $description=$arr->hallfame[$y]->description;
				 $average=$arr->hallfame[$y]->average;
			if ($title != "") {	
				echo "<img src=".$cover." width='200'/>";
				echo "<div class ='feed-title'>" . $title. "</div>";
				echo "<div class ='feed-content'>" . $description. "</div>";
				echo "<div class ='feed-updated'>Average: " . $average. "</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
			}
				$y++;
			}



?>			
				</div>
				<button onclick="sharefame()" class="fanedit styled" type="button">Fame XML Link</button>
			</div>
			<!-- Hall of Shame RSS -->
			<div class="rss-container">
				<div class="rss-title">Hall of Shame</div>
				<div class="rss-content">
	<?php
			$get = file_get_contents('hallshame.xml');
			$arr = simplexml_load_string($get);
			 $y=0;
			 $x = 10;
			while ($y<=$x){
			 	 $cover=$arr->hallshame[$y]->cover;
			 	 $title=$arr->hallshame[$y]->name;
				 $description=$arr->hallshame[$y]->description;
				 $average=$arr->hallshame[$y]->average;
			if ($title != "") {	
				echo "<img src=".$cover." width='200'/>";
				echo "<div class ='feed-title'>" . $title. "</div>";
				echo "<div class ='feed-content'>" . $description. "</div>";
				echo "<div class ='feed-updated'>Average: " . $average. "</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
			}
				$y++;
			}



?>			
				</div>
				<button onclick="shareshame()" class="fanedit styled" type="button">Shame XML Link</button>
			</div>
			<!-- Up and Coming RSS -->
			<div class="rss-container">
				<div class="rss-title">Up and Coming</div>
				<div class="rss-content">
<?php
			$get = file_get_contents('upncoming.xml');
			$arr = simplexml_load_string($get);
			 $y=0;
			 $x = 10;
			while ($y<=$x){
			 	 $cover=$arr->upncoming[$y]->cover;
			 	 $title=$arr->upncoming[$y]->name;
				 $description=$arr->upncoming[$y]->description;
				 $average=$arr->upncoming[$y]->average;
			if ($title != "") {	
				echo "<img src=".$cover." width='200'/>";
				echo "<div class ='feed-title'>" . $title. "</div>";
				echo "<div class ='feed-content'>" . $description. "</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
			}
				$y++;
			}



?>			
				</div>
	<button onclick="shareupncoming()" class="fanedit styled" type="button">Up n Coming XML</button>			
			</div>
		</div>
	</div>
	<?php include('footer.php');

		
  	$drp1 = "DROP  TABLE IF EXISTS TEMP_FAMESHAME_TABLE";
       mysql_query($drp1 ) or ( "Error " . mysql_error () ) ; 	
	
	
	?>


	?>
</body>
</html>