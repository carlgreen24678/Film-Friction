<?php
require_once "conninc.php";

		  
	 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE WHERE temp_filmaverage > '0' ORDER BY temp_filmaverage ASC LIMIT 10"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				
				
	//create a new xml object
			$xml = new SimpleXMLElement('<hallshames/>');			
				
				
				while($row3=mysql_fetch_array($r3)) {				

					
					$t_filmid=$row3["temp_filmid"];
					$t_filmaverage=$row3["temp_filmaverage"];
					$t_toxic=$row3["temp_toxic"];
					$t_below=$row3["temp_below"];
					$t_average=$row3["temp_average"];
					$t_thumbs=$row3["temp_thumbs"];
					$t_hot=$row3["temp_hot"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover=$row2["cover"];
						$f_filmid=$row2["id"];
						$rssfame_title=$row2["name"];
						$rssfame_desc=$row2["description"];
						$rssfame_cover= "http://www.filmfriction.com/images/films/" .$row2["cover"];
					}					
				
				$rssfame_title = str_replace("&", "&amp;", $rssfame_title);
				$rssfame_title = str_replace("<", "&lt;", $rssfame_title);
				$rssfame_title = str_replace(">", "&gt;", $rssfame_title);
				$rssfame_title = str_replace("\"", "&quot;", $rssfame_title);
				$rssfame_desc = str_replace("&", "&amp;", $rssfame_desc);
				$rssfame_desc = str_replace("<", "&lt;", $rssfame_desc);
				$rssfame_desc = str_replace(">", "&gt;", $rssfame_desc);
				$rssfame_desc = str_replace("\"", "&quot;", $rssfame_desc);				
		
	
				$member = $xml->addChild('hallshame');
					$member->addChild('cover', $rssfame_cover);
					$member->addChild('name', $rssfame_title);
					$member->addChild('description', $rssfame_desc);
					$member->addChild('average', $t_filmaverage);
				
				}	  






$xml->asXML("hallshame.xml");

?>