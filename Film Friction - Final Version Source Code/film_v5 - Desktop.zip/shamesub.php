<?php
session_start();
		$store_email = $_REQUEST['em'];
		$visitor_email = 'subscribed@filmfriction.com';
		$to = $store_email;
		$subject="Film Friction - Hall of shame Subscription";
		$from = $visitor_email;
		$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
		
		
		$body = '<html><body>';
		$body = "Thank you for subscribing to the Film Friction Hall of Shame page\n";
		$body .= "<br>";
		$body .= "<br>";
		$body .= "<br>";
		$body .= "<br>";
		$body .= "<br>";
		$body .= "<br>";
		$body .= '<a href="http://www.filmfriction.com/shameunsub.php?id='; 
		$body .= $store_email;
		$body .= '">Click here to Unsubscribe</a>'; 
		$body .= '</a>'; 
		$body .= '</body></html>';
		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $visitor_email \r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		
		mail($to, $subject, $body, $headers);

		require_once "conninc.php";
		$exist = 0;
		
		$q2 = "SELECT * FROM shamesubscription WHERE email = '$store_email' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
				$status=$row2["status"];
			    if ($status == 0) {
					$q4 = "UPDATE `shamesubscription` SET `status` = '1' WHERE `shamesubscription`.`email` = '$store_email'";
					$r4 = mysql_query($q4);
					echo mysql_error();		
					$exist = 1;
				}

				
				if ($status == 1) {
					$exist = 1;
				}
			}
		
		if ($exist != 1) {
			$q3 = "INSERT INTO shamesubscription (email, joindate) VALUES ('$store_email', NOW() )";       		
			$r3 = mysql_query($q3);
			echo mysql_error();
		}
		header('Location: index.php');	

?>
