<?php
require_once "conninc.php";

	$q2 = "SELECT * FROM famechat ORDER BY id ASC";
	 
	$r2 = mysql_query($q2)or die($q2."<br/><br/>".mysql_error());
	while($row2=mysql_fetch_array($r2)) {
	
        $f_username=$row2["username"];
        $f_text=$row2["text"];
        $f_time=date('G:i', strtotime($row2["time"])); //outputs date as # #Hour#:#Minute#;

        echo "<p>$f_username: $f_text</p>\n";
    }

?>