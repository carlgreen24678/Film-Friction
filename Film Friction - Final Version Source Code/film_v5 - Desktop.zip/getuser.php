<?php

require_once "conninc.php";
			$q2 = "SELECT * FROM user WHERE id = '$userid' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {
				$name=$row2["username"];
				$avatar=$row2["avatar"];
				$bio=$row2["bio"];
			}	
			 
	
	
?>