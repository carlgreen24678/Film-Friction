<?php
		require_once "conninc.php";

		$q2 = "SELECT * FROM watched WHERE filmid = '$storeid' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
			$watch_count = $row2["count"];
			$watch_count ++;
			$watch_exist = 1;			
			}
		if ($watch_exist == 0) {
			
		require_once "conninc.php";
		$q3 = "INSERT INTO watched (filmid, count) VALUES ('$storeid', '1')";       		
			  $r3 = mysql_query($q3);
			echo mysql_error();
		}
		else {
		require_once "conninc.php";
		$q3 = "UPDATE watched set count = '{$watch_count}' WHERE filmid = '$storeid'";       		
			  $r3 = mysql_query($q3);
			echo mysql_error();			
		}


?>
