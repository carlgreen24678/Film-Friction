<?php
require_once "conninc.php";
//get user-input from url
$t_username=substr($_GET["t_username"], 0, 32);
$t_text=substr($_GET["t_text"], 0, 128);
//escaping is extremely important to avoid injections!
$t_nameEscaped = htmlentities(mysql_real_escape_string($t_username)); //escape username and limit it to 32 chars
$t_textEscaped = htmlentities(mysql_real_escape_string($t_text)); //escape text and limit it to 128 chars


//execute query
	$t_chat = "INSERT INTO trendchat (username, text) VALUES ('$t_nameEscaped', '$t_textEscaped')"; 
	mysql_query($t_chat)or die (mysql_errno()."<br/>".mysql_error()); 
?>

