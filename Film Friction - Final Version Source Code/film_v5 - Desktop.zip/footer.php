<div id="footer">
	<div class="footer-logo">
		<img alt="End Gain Solutions" src="images/endgain.png" class="endgain">
	</div>
	<div class="copy">
		<p class="copyright">&copy; End Gain Solutions 2019</p>
	</div>
</div>