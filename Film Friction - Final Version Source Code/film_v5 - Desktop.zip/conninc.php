<?php

 $connid = mysql_connect('localhost', 'ffadmin', 'FilmFriction1#', 'world');
 $r = @mysql_select_db("filmfriction", $connid) or die("Err");
 
 ?>