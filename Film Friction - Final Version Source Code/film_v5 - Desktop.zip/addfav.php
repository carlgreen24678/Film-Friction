<?php
		$store_user = $_REQUEST['us'];
		$store_film = $_REQUEST['fm'];
		$fav_exist = 0;
		require_once "conninc.php";

		$q2 = "SELECT * FROM filmfavourite WHERE userid = '$store_user' && filmid = '$store_film' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
			$fav_exist = 1;			
			}
		if ($fev_exist == 0) {
			
		require_once "conninc.php";
		$q3 = "INSERT INTO filmfavourite (userid, filmid) VALUES ('$store_user', '$store_film')";       		
			  $r3 = mysql_query($q3);
			echo mysql_error();
		}
	
		header('Location: index.php?fv=2');	

?>
