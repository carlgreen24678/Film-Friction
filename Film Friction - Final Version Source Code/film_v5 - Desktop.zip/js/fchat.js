$(document).ready(function() {
	var f_chatInterval = 250; //refresh interval in ms
    var $f_userName = $("#f_userName");
    var $f_chatOutput = $("#f_chatOutput");
    var $f_chatInput = $("#f_chatInput");
    var $f_chatSend = $("#f_chatSend");
    function f_sendMessage() {
        var f_userNameString = $f_userName.val();
        var f_chatInputString = $f_chatInput.val();
        

		$.get("./famechatwrite.php", {
            f_username: f_userNameString,
            f_text: f_chatInputString
        });

        f_retrieveMessages();
    }

    function f_retrieveMessages() {
        $.get("./famechatread.php", function(f_data) {
            $f_chatOutput.html(f_data); //Paste content into chat output
        });
    }

    $f_chatSend.click(function() {
        f_sendMessage();
    });

    setInterval(function() {
        f_retrieveMessages();
    }, f_chatInterval);
});