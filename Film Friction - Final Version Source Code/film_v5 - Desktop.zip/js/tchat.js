$(document).ready(function() {
	var t_chatInterval = 250; //refresh interval in ms
    var $t_userName = $("#t_userName");
    var $t_chatOutput = $("#t_chatOutput");
    var $t_chatInput = $("#t_chatInput");
    var $t_chatSend = $("#t_chatSend");
    function t_sendMessage() {
        var t_userNameString = $t_userName.val();
        var t_chatInputString = $t_chatInput.val();
        

		$.get("./trendchatwrite.php", {
            t_username: t_userNameString,
            t_text: t_chatInputString
        });

        t_retrieveMessages();
    }

    function t_retrieveMessages() {
        $.get("./trendchatread.php", function(t_data) {
            $t_chatOutput.html(t_data); //Paste content into chat output
        });
    }

    $t_chatSend.click(function() {
        t_sendMessage();
    });

    setInterval(function() {
        t_retrieveMessages();
    }, t_chatInterval);
});