<?php
		$store_email = $_REQUEST['id'];

		require_once "conninc.php";

		$q2 = "SELECT * FROM trendsubscription WHERE email = '$store_email' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
				$status=$row2["status"];
			    if ($status == 1) {
					$q4 = "UPDATE `trendsubscription` SET `status` = '0', `unsubdate` = NOW() WHERE `trendsubscription`.`email` = '$store_email'";
					$r4 = mysql_query($q4);
					echo mysql_error();		
					$exist = 1;
				}
			}
	
	
		header('Location: index.php?un=2');	

?>
