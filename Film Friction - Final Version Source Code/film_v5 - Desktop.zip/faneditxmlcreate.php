<?php
require_once "conninc.php";
$q1 = "SELECT * FROM rssfanedit ORDER BY id ASC";
			  
			  $r1 = mysql_query($q1); 
			  echo mysql_error();

//create a new xml object
$xml = new SimpleXMLElement('<fanedits/>');

//loop through the data, and add each record to the xml object
	while($row1=mysql_fetch_array($r1)) {
		$rssfan_title = $row1['title'];
		$rssfan_content = $row1['content'];
		$rssfan_updated = $row1['updated'];
		$rssfan_title = str_replace("&", "&amp;", $rssfan_title);
		$rssfan_title = str_replace("<", "&lt;", $rssfan_title);
		$rssfan_title = str_replace(">", "&gt;", $rssfan_title);
		$rssfan_title = str_replace("\"", "&quot;", $rssfan_title);
		$rssfan_content = str_replace("&", "&amp;", $rssfan_content);
		$rssfan_content = str_replace("<", "&lt;", $rssfan_content);
		$rssfan_content = str_replace(">", "&gt;", $rssfan_content);
		$rssfan_content = str_replace("\"", "&quot;", $rssfan_content);		
		$rssfan_updated = str_replace("&", "&amp;", $rssfan_updated);
		$rssfan_updated = str_replace("<", "&lt;", $rssfan_updated);
		$rssfan_updated = str_replace(">", "&gt;", $rssfan_updated);
		$rssfan_updated = str_replace("\"", "&quot;", $rssfan_updated);		
			
		
	
	$member = $xml->addChild('fanedit');
		$member->addChild('title', $rssfan_title);
		$member->addChild('content', $rssfan_content);
		$member->addChild('updated', $rssfan_updated);
}


$xml->asXML("fanedit.xml");

?>