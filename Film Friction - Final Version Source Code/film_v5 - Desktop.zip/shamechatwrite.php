<?php
require_once "conninc.php";
//get user-input from url
$s_username=substr($_GET["s_username"], 0, 32);
$s_text=substr($_GET["s_text"], 0, 128);
//escaping is extremely important to avoid injections!
$s_nameEscaped = htmlentities(mysql_real_escape_string($s_username)); //escape username and limit it to 32 chars
$s_textEscaped = htmlentities(mysql_real_escape_string($s_text)); //escape text and limit it to 128 chars


//execute query
	$s_chat = "INSERT INTO shamechat (username, text) VALUES ('$s_nameEscaped', '$s_textEscaped')"; 
	mysql_query($s_chat)or die (mysql_errno()."<br/>".mysql_error()); 
?>

