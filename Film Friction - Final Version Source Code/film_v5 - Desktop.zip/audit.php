<?php
require_once "conninc.php";
$q3 = "INSERT INTO userhistory (userid, filmid, watcheddate) VALUES ('$storeuser', '$storeid', NOW() )";       		
      $r3 = mysql_query($q3);
	echo mysql_error();
 
?>