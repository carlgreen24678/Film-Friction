<?php
if(isset($_POST['login']) AND $_POST['login'] != "")

{

$username = $_POST['username'];
$password = $_POST['password'];

require "conninc.php";


$q1 = "SELECT * FROM user WHERE username = '$username' && password = '$password' LIMIT 1";
	 $r1 = mysql_query($q1);	
while( $row1=mysql_fetch_array($r1)) {	
	$userid=$row1["id"];	
	$_SESSION["userName"] = $username;
	$_SESSION["userID"] = $userid;

}
echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
 
exit;

	
}
$username = "";
$password = "";

?>
		<script type="text/javascript">
		$(document).ready(function() {
		  $("#searchterm").autocomplete({
			  source:"mng_search.php",
			  minLength: 2,
			  select: function(event, ui) {
				  window.location="film.php?f="+ui.item.id;
			  }
			  });  
		});
		</script>	



<link rel="stylesheet" type="text/css" href="js/jquery-ui.css"/>


<div id="header">
	<img class="ff-banner" alt="Film Friction" src="images/ff-banner.png">
	<div id="main-nav">
		<a href="index.php">Home</a>
		<a href="about.php">About</a>
		<a href="new-and-trending.php">New and Trending</a>
		<a href="hall-of-fame.php">Hall of Fame</a>
		<a href="hall-of-shame.php">Hall of Shame</a>
		<a href="up-and-coming.php">Up and Coming</a>
		<a href="rss-feeds.php">RSS Feeds</a>
		<a href="contact.php">Contact Us</a>
		<div class="dropdown" style="float: right">
<?php		

	if ($userflag == 0) {
		echo "<button class='dropbtn'>Login</button>
		<div class='dropdown-content'>
				
				<form name='register' method='post'>
					<p class='login-text'>Username:</p>
					<input type='text' name='username' value='$username' required class='login-field'>
					<p class='login-text'>Password:</p>
					<input type='password' name='password' value='$password' required class='login-field'>
					<input type='submit' name='login' value='Submit' class='reg-button'>
				</form>
			";
	}else {
		echo "	<a href='my-profile.php'>My Profile</a>";
	}	
	if ($userflag != 1) {
	echo "</div>";
	}
	if ($userflag == 1) {
		echo "<a href='logout.php'>Logout</a>";
	}else {
		echo "<a href='register.php' style='float: right'>Register</a>";
	}
	?>

		
	</div>
	</div>

	<div class="search">
<?php
	if ($userflag != 0) { ?>	
		<div class = "search_class">
 
				<input type="search" name="searchterm" id="searchterm" placeholder="Search Film Friction..."/>
		</div>
 
		
	

<?php
	}
?>		
	</div>
	
</div>