
	<div class="t_userSettings">
 
            <input id="t_userName" type="hidden" placeholder="Username" value ="<?php echo $userName; ?>">
            </div>
            <div class="t_chat">
                <div id="t_chatOutput"></div>
                
    <?php 
			if (isset($_SESSION['userName'])) {
			echo "<input id='t_chatInput' type='text' placeholder='Type here' maxlength='128'>";
			echo "<button id='t_chatSend'>Send</button>";
			}
	?>		
            </div>

