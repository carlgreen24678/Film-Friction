<?php
		require_once "conninc.php";

		$vote_total = 0;
		$vote_count = 0;
		$vote_count_toxic = 0;
		$vote_count_below = 0;
		$vote_count_average = 0;
		$vote_count_thumbs = 0;
		$vote_count_hot = 0;
		
		$q2 = "SELECT * FROM vote WHERE filmid = '$storeid' ORDER BY vote";
		$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			
			while($row2=mysql_fetch_array($r2)) {		
			
			$vote=$row2["vote"];
			$vote_count ++;
			$vote_total = $vote_total + $vote;
			if ($vote == 1) { $vote_count_toxic ++; }
			if ($vote == 2) { $vote_count_below ++; }
			if ($vote == 3) { $vote_count_average ++; }
			if ($vote == 4) { $vote_count_thumbs ++; }
			if ($vote == 5) { $vote_count_hot ++; }
						
			}
		$vote_average = ceil($vote_total / $vote_count);

?>
