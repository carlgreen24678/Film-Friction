<?php
session_start();
$userflag = 0;

 if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
	$store_subs = $_REQUEST['un'];
	




if (!isset($_SESSION['userName'])) { 

 echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
}
$storeuser = $_SESSION['userID'];
$storeid = $_REQUEST['f'];


include('audit.php');
include('getfilm.php');
include('getvotes.php');
include('watched.php')

?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>Film Name Here...</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="film.css" rel="stylesheet" type="text/css" />
		
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
		<script>
		function sharealert() {
		  var filmlink = "<?php echo $film_video ?>";
		  
		  alert("Thank you for sharing a film trailer please copy the link provided:            " + filmlink);
		}
		</script>		
		<script type="text/javascript">
					function addfavourite(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var filmname = "<?php echo $film_name ?>";	
					var filmfav = confirm("Add the following film to favourites?\n" + filmname);
					if (filmfav == true) {
					  window.location = "addfav.php?us=" + userid + "&fm=" + filmid;
					} else {

					}
					}
		</script>
			
	<script type="text/javascript">
					function delfavourite(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var filmname = "<?php echo $film_name ?>";	
					var filmfav = confirm("Remove the following film to favourites?\n" + filmname);
					if (filmfav == true) {
					  window.location = "delfav.php?us=" + userid + "&fm=" + filmid;
					} else {

					}
					}
		</script>	
	<script type="text/javascript">
					function votetoxic(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var votelevel = "<?php echo "1" ?>";	
					window.location = "vote.php?us=" + userid + "&fm=" + filmid + "&vt=" + votelevel;
					}
		</script>
	<script type="text/javascript">
					function votebelow(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var votelevel = "<?php echo "2" ?>";	
					window.location = "vote.php?us=" + userid + "&fm=" + filmid + "&vt=" + votelevel;
					}
		</script>
	<script type="text/javascript">
					function voteaverage(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var votelevel = "<?php echo "3" ?>";	
					window.location = "vote.php?us=" + userid + "&fm=" + filmid + "&vt=" + votelevel;
					}
		</script>
	<script type="text/javascript">
					function votethumbs(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var votelevel = "<?php echo "4" ?>";	
					window.location = "vote.php?us=" + userid + "&fm=" + filmid + "&vt=" + votelevel;
					}
		</script>		
	<script type="text/javascript">
					function votehot(){
					var userid = "<?php echo $storeuser ?>";	
					var filmid = "<?php echo $storeid ?>";	
					var votelevel = "<?php echo "5" ?>";	
					window.location = "vote.php?us=" + userid + "&fm=" + filmid + "&vt=" + votelevel;
					}
		</script>		




		
			
		
		
		
		
	</head>
<body>
	<?php include('header.php');
	?>
	<div class="page-title"><?php echo $film_name ?></div>
	<div class="film-container">
		<div class="filmbg-container" style="background-image:url(images/filmbackground/<?php echo $film_background ?>); background-size : cover; ">

		</div>
		<div class="filminfo-container">
			<div class="film-title">Description</div>
			<div class="film-rating">
			</div>
			<div class="film-info">
				<p class="filminfo-text"><?php echo $film_description ?></p>
			</div>
			<div class="film-options">
					<div class ="film_btn_hlder">
						<button onclick="sharealert()" class = "share_button" style="cursor: pointer; height:100%;"   alt="Share this fan edit on social media" title="Share this fan edit on social media" >
					</button>
					</div>
	<?php				
			if($favourited == 0) {	?>	
					<div class ="film_btn_hlder">
						<button onclick="addfavourite()" class = "favourite_button" style="cursor: pointer; height:100%;"   alt="Add to favourites" title="Add to favourites" >
					</button>
					</div>					
	<?php		}else { ?>
					<div class ="film_btn_hlder">
						<button onclick="delfavourite()" class = "unfavourite_button" style="cursor: pointer; height:100%;"   alt="Remove from favourites" title="Remove from favourites" >
					</button>
					</div>					
	<?php		}	?>
			</div>
				<div class="film-trailer">
					<button class="trailer-btn" onclick="window.open('<?php echo $film_video ?>','_blank','resizable=yes')" />Watch the Trailer</button>
				</div>
		</div>
		<div class="filmratings-container">
			<div class="rating">
					<img class="ff-rating" alt="Toxic Ratings" src="images/rate one.png" onclick="votetoxic()" style="cursor: pointer;" alt="Vote Toxic" title="Vote Toxic">
					<p class="ff-rating-num">
						<?php echo $vote_count_toxic; ?>
					</p>
				</div>
				<div class="rating">
					<img class="ff-rating" alt="Below Par Ratings" src="images/rate two.png" onclick="votebelow()" style="cursor: pointer;" alt="Vote Below Par" title="Vote Below Par">
					<p class="ff-rating-num">
						<?php echo $vote_count_below; ?>
					</p>
				</div>
				<div class="rating">
					<img class="ff-rating" alt="Average Ratings" src="images/rate three.png" onclick="voteaverage()" style="cursor: pointer;" alt="Vote Average" title="Vote Average">
					<p class="ff-rating-num">
						<?php echo $vote_count_average; ?>
					</p>
				</div>
				<div class="rating">
					<img class="ff-rating" alt="Thumbs Up Ratings" src="images/rate four.png" onclick="votethumbs()" style="cursor: pointer;" alt="Vote Thumbs Up" title="Vote Thumbs Up">
					<p class="ff-rating-num">
						<?php echo $vote_count_thumbs; ?>
					</p>
				</div>
				<div class="rating" style="margin-right: 0">
					<img class="ff-rating" alt="Hot Stuff Ratings" src="images/rate five.png" onclick="votehot()" style="cursor: pointer;" alt="Vote Hot Stuff" title="Vote Hot Stuff">
					<p class="ff-rating-num">
						<?php echo $vote_count_hot; ?>
					</p>
				</div>
				<div class="avg-rating">
				<?php echo "Average Rating " . $vote_average; ?>
				</div>
		</div>
	</div>
	<?php include('footer.php'); ?>
</body>
</html>

<!--
<img class="filmbgimg" alt="" src="https://via.placeholder.com/1500x600.png">