<?php

require_once "conninc.php";
			$q2 = "SELECT * FROM films WHERE id = '$storeid' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {
				$film_name=$row2["name"];
				$film_description=$row2["description"];
				$film_releasedate=$row2["releasedate"];
				$film_runningtime=$row2["runningtime"];
				$film_cover=$row2["cover"];
				$film_video=$row2["video"];
				$film_background=$row2["background"];
			}	
			 
	
	$favourited = 0;		

	require_once "conninc.php";
			$q2 = "SELECT * FROM filmfavourite WHERE userid = '$storeuser' && filmid = '$storeid' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {
				$favourited = 1;
			}				
			
			
?>