<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
?>


<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>Hall of Fame</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="hall.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
	</head>
<body>
	<?php include('header.php');
		  include('fameshame.php');
		  
	 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE WHERE temp_filmaverage > '0' ORDER BY temp_filmaverage DESC LIMIT 10"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$t_filmaverage[$famecount]=$row3["temp_filmaverage"];
					$t_toxic[$famecount]=$row3["temp_toxic"];
					$t_below[$famecount]=$row3["temp_below"];
					$t_average[$famecount]=$row3["temp_average"];
					$t_thumbs[$famecount]=$row3["temp_thumbs"];
					$t_hot[$famecount]=$row3["temp_hot"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmdescription[$famecount]=$row2["description"];
						$f_filmbackground[$famecount]=$row2["background"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
						$famecount ++;
					}					

				}	  

	
	?>
	<div class="page-title">
		Hall of Fame
<a href="rss-feeds.php"><img src="images/rss-btn.png" style="justify-content: flex-end; width: 26%; height: 95%; border: none; border-radius: 5px; margin-left: 30%;"></a>
		 
	</div>
	<div class="hall-title">The best of the bunch</div>
	
	<div class="hall-container"><!-- Film 1 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[0];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[0]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[0]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[0],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[0];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 2 -->
			<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[1];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[1]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[1]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[1],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[1];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 3 -->
			<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[2];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[2]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[2]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[2],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[2];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 4 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[3];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[3]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[3]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[3],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[3];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 5 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[4];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[4]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[4]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[4],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[4];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 6 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[5];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[5]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[5]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[5],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[5];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 7 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[6];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[6]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[6]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[6],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[6];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 8 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[7];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[7]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[7]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[7],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[7];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 9 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[8];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[8]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[8]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[8],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[8];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 10 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[9];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[9]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[9]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[9],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[9];?>">More...</a</button>
		</div>
	</div>
	
<?php	
		unset ($w_filmid, $f_filmcover, $t_filmid, $t_filmaverage, $t_toxic, $t_below, $t_average, $t_thumbs, $t_hot, $f_filmid, $f_filmname  );
	//	unset ($f_filmcover);
		$famecount = 0;
		$q4 = "SELECT * FROM watched ORDER BY count DESC LIMIT 6"; 
			$r4 = mysql_query($q4)or die($myQuery."<br/><br/>".mysql_error());
				while($row4=mysql_fetch_array($r4)) {				
					$w_filmid=$row4["filmid"]; 
					 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE WHERE temp_filmid = '$w_filmid' LIMIT 1"; 
						$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
							while($row3=mysql_fetch_array($r3)) {				
								$t_filmid=$row3["temp_filmid"];
								$t_filmaverage[$famecount]=$row3["temp_filmaverage"];
								$t_toxic[$famecount]=$row3["temp_toxic"];
								$t_below[$famecount]=$row3["temp_below"];
								$t_average[$famecount]=$row3["temp_average"];
								$t_thumbs[$famecount]=$row3["temp_thumbs"];
								$t_hot[$famecount]=$row3["temp_hot"];
								$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
								$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
								while($row2=mysql_fetch_array($r2)) {
									$f_filmdescription[$famecount]=$row2["description"];
									$f_filmbackground[$famecount]=$row2["background"];									
									$f_filmcover[$famecount]=$row2["cover"];
									$f_filmid[$famecount]=$row2["id"];
									$f_filmname[$famecount]=$row2["name"];
									$famecount ++;
								}					

							}	  	
				}


?>		
	
	

	
	<!-- Most Watched Section -->
	<div class="hall-title">Most Watched</div>
<div class="hall-container"><!-- Film 1 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[0];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[0]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[0]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[0],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[0];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 2 -->
			<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[1];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[1]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[1]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[1],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[1];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 3 -->
			<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[2];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[2]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[2]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[2],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[2];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 4 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[3];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[3]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[3]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[3],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[3];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 5 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[4];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[4]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[4]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[4],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[4];?>">More...</a</button>
		</div>
	</div>
	<div class="hall-container"><!-- Film 6 -->
		<div class="hall-image">
		<a href="film.php?f=<?php echo $f_filmid[5];?>">
				<img alt="" src="images/filmbackground/<?php echo $f_filmbackground[5]; ?>"style="width: 100%; height: 100%"></a>
		</div>
		<div class="hall-info">
			<div class="hall-film-title">
		<?php		echo $f_filmname[5]; ?>
			</div>
		<?php 
			$string = substr($f_filmdescription[5],0,200).'...';
			echo $string; 
			?>.
			<button class="hall-btn"><a href="film.php?f=<?php echo $f_filmid[5];?>">More...</a</button>
		</div>
	</div>
	<?php include('footer.php');
		
	$drp1 = "DROP  TABLE IF EXISTS TEMP_FAMESHAME_TABLE";
     mysql_query($drp1 ) or ( "Error " . mysql_error () ) ; 	

	?>
</body>
</html>