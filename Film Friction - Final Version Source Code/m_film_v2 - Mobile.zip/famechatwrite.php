<?php
require_once "conninc.php";
//get user-input from url
$f_username=substr($_GET["f_username"], 0, 32);
$f_text=substr($_GET["f_text"], 0, 128);
//escaping is extremely important to avoid injections!
$f_nameEscaped = htmlentities(mysql_real_escape_string($f_username)); //escape username and limit it to 32 chars
$f_textEscaped = htmlentities(mysql_real_escape_string($f_text)); //escape text and limit it to 128 chars


//execute query
	$f_chat = "INSERT INTO famechat (username, text) VALUES ('$f_nameEscaped', '$f_textEscaped')"; 
	mysql_query($f_chat)or die (mysql_errno()."<br/>".mysql_error()); 
?>

