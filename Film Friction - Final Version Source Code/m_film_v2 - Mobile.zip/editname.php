<?php
		$store_id = $_REQUEST['us'];
		$store_name = $_REQUEST['name'];

		require_once "conninc.php";
		$q4 = "UPDATE `user` SET `username` = '$store_name'  WHERE `user`.`id` = '$store_id'";
					$r4 = mysql_query($q4);
					echo mysql_error();		
	
		header('Location: my-profile.php');	

?>
