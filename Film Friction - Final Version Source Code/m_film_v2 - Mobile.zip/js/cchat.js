$(document).ready(function() {
	var c_chatInterval = 250; //refresh interval in ms
    var $c_userName = $("#c_userName");
    var $c_chatOutput = $("#c_chatOutput");
    var $c_chatInput = $("#c_chatInput");
    var $c_chatSend = $("#c_chatSend");
    function c_sendMessage() {
        var c_userNameString = $c_userName.val();
        var c_chatInputString = $c_chatInput.val();
        

		$.get("./comingchatwrite.php", {
            c_username: c_userNameString,
            c_text: c_chatInputString
        });

        c_retrieveMessages();
    }

    function c_retrieveMessages() {
        $.get("./comingchatread.php", function(c_data) {
            $c_chatOutput.html(c_data); //Paste content into chat output
        });
    }

    $c_chatSend.click(function() {
        c_sendMessage();
    });

    setInterval(function() {
        c_retrieveMessages();
    }, c_chatInterval);
});