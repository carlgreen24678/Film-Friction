$(document).ready(function() {
	var s_chatInterval = 250; //refresh interval in ms
    var $s_userName = $("#s_userName");
    var $s_chatOutput = $("#s_chatOutput");
    var $s_chatInput = $("#s_chatInput");
    var $s_chatSend = $("#s_chatSend");
    function s_sendMessage() {
        var s_userNameString = $s_userName.val();
        var s_chatInputString = $s_chatInput.val();
        

		$.get("./shamechatwrite.php", {
            s_username: s_userNameString,
            s_text: s_chatInputString
        });

        s_retrieveMessages();
    }

    function s_retrieveMessages() {
        $.get("./shamechatread.php", function(s_data) {
            $s_chatOutput.html(s_data); //Paste content into chat output
        });
    }

    $s_chatSend.click(function() {
        s_sendMessage();
    });

    setInterval(function() {
        s_retrieveMessages();
    }, s_chatInterval);
});