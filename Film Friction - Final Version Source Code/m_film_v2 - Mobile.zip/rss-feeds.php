<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>RSS Feeds</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="rss.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
	</head>
<body>
<?php include('header.php');
		include('famexmlcreate.php');
		include('shamexmlcreate.php');
		include('upxmlcreate.php');
	?>
	<div class="page-title">RSS Feeds</div>
		<div class="rss-main-container">
			<!-- New and Trending RSS -->
			<button class="collapsible">New and Trending Feed</button>
			<div class="content">
<?php
include('atomgrab.php') ?>			

			</div>
			
			<!-- Hall of Fame RSS -->
			<button class="collapsible">Hall of Fame Feed</button>
			<div class="content">
<?php
			$get = file_get_contents('hallfame.xml');
			$arr = simplexml_load_string($get);
			 $y=0;
			 $x = 10;
			while ($y<=$x){
			 	 $cover=$arr->hallfame[$y]->cover;
			 	 $title=$arr->hallfame[$y]->name;
				 $description=$arr->hallfame[$y]->description;
				 $average=$arr->hallfame[$y]->average;
			if ($title != "") {	
				echo "<img src=".$cover." width='200'/>";
				echo "<div class ='feed-title'>" . $title. "</div>";
				echo "<div class ='feed-content'>" . $description. "</div>";
				echo "<div class ='feed-updated'>Average: " . $average. "</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
			}
				$y++;
			}



?>			
				</div>
			
			<!-- Hall of Shame RSS -->
			<button class="collapsible">Hall of Shame Feed</button>
			<div class="content">
<?php
			$get = file_get_contents('hallshame.xml');
			$arr = simplexml_load_string($get);
			 $y=0;
			 $x = 10;
			while ($y<=$x){
			 	 $cover=$arr->hallshame[$y]->cover;
			 	 $title=$arr->hallshame[$y]->name;
				 $description=$arr->hallshame[$y]->description;
				 $average=$arr->hallshame[$y]->average;
			if ($title != "") {	
				echo "<img src=".$cover." width='200'/>";
				echo "<div class ='feed-title'>" . $title. "</div>";
				echo "<div class ='feed-content'>" . $description. "</div>";
				echo "<div class ='feed-updated'>Average: " . $average. "</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
			}
				$y++;
			}



?>			
				</div>
			
			<!-- Up and Coming RSS -->
			<button class="collapsible">Up and Coming Feed</button>
			<div class="content">
	<?php
			$get = file_get_contents('upncoming.xml');
			$arr = simplexml_load_string($get);
			 $y=0;
			 $x = 10;
			while ($y<=$x){
			 	 $cover=$arr->upncoming[$y]->cover;
			 	 $title=$arr->upncoming[$y]->name;
				 $description=$arr->upncoming[$y]->description;
				 $average=$arr->upncoming[$y]->average;
			if ($title != "") {	
				echo "<img src=".$cover." width='200'/>";
				echo "<div class ='feed-title'>" . $title. "</div>";
				echo "<div class ='feed-content'>" . $description. "</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
				echo "<div class ='feed-title'>-----------------------------------------</div>";
			}
				$y++;
			}



?>			
				</div>
			
			<script>
				var coll = document.getElementsByClassName("collapsible");
				var i;

				for (i = 0; i < coll.length; i++) {
				  coll[i].addEventListener("click", function() {
					this.classList.toggle("active");
					var content = this.nextElementSibling;
					if (content.style.display === "block") {
					  content.style.display = "none";
					} else {
					  content.style.display = "block";
					}
				  });
				}
			</script>
		</div>
	</div>
	<?php include('footer.php') ?>
</body>
</html>