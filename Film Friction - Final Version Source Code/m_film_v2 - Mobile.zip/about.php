<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
    $userid = $_SESSION['userID'];
	$userflag = 1;
	} 
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>About Film Friction</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="about.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
	</head>
<body>
	<?php include('header.php') ?>
	<div class="page-title">About Film Friction</div>
	<div class="about-container">
		<p class="about-text">
			The aim of this application is to create an avenue for otherwise missed or dismissed fan made edits.<br><br>
			Even encourage the audience to participate and become part of the community.<br><br>
			Creating a destination of interest where fresh content and edits of blockbuster movies can be presented and shared.<br><br>
			The intention is to spark an interest in assessing what is currently in popular culture, in this case Hollywood films.<br><br>
			And present alternative versions of this media which an individual may wish to consume.
		</p>
	</div>
	<?php include('footer.php') ?>
</body>
</html>