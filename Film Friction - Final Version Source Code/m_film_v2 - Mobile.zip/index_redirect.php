<!DOCTYPE html>
<html lang="en">
	<!doctype html>
	<html>
		<head>
			<script src="redirection-mobile.js"></script>
			<script>
				SA.redirection_mobile({
				tablet_redirection : "true",
				tablet_host : "t.filmfriction.com",
				tablet_prefix : "http"
				});
			</script>
		</head>

