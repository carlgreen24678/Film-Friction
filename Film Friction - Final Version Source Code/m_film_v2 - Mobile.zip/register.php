<?php
session_start();

 if (isset($_SESSION['userName']))
{
    
	
	header("location:index.php");

    exit(); 
} 

if(isset($_POST['submit']) AND $_POST['submit'] != "")

{

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];


require "conninc.php";

$username = addslashes($username); 
$password = addslashes($password); 
$email = addslashes($email); 


$q3 = "INSERT INTO user (username, password, email, created) VALUES ('$username', '$password', '$email', NOW() )";       		
      $r3 = mysql_query($q3);
      
	echo mysql_error();
 
$_SESSION["userName"] = $username;
 
 echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
 
exit;

	
}

$username="";
$password="";
$email="";

?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>Register for Film Friction</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="register.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
		<!-- Password strength checker script -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/zxcvbn/4.2.0/zxcvbn.js"></script>
	</head>
<body>
	<?php include('header.php') ?>
	<div class="page-title">Register</div>
		<div class="reg-container">
			<form action="" method="" id="" class="reg-form">
				<p class="label">Username:</p> 
				<input type="text" name="" placeholder="Enter a username..." class="reg-field" value="<?php '$username' ?>" required>
				<p class="label">Email:</p> 
				<input type="text" name="" placeholder="Enter your email address..." class="reg-field" value="<?php '$email' ?>" required>
				<p class="label">Password:</p> 
				<input type="password" name="" id="password" placeholder="Enter a password..." class="reg-field" value="<?php '$password' ?> required style="margin-bottom: 0">
				<meter max="4" id="password-strength-meter" value="0"></meter>
				<p id="password-strength-text"></p>
				<p class="label">Repeat Password:</p> 
				<input type="password" name="" placeholder="Repeat and confirm your password..." class="reg-field" required>
				<input type="submit" value="Sign Up" class="reg-button">
			</form>
			<script>
				var strength = {
				0: "Worst ☹",
				1: "Bad ☹",
				2: "Weak ☹",
				3: "Good ☺",
				4: "Strong ☻"
				}

				var password = document.getElementById('password');
				var meter = document.getElementById('password-strength-meter');
				var text = document.getElementById('password-strength-text');

				password.addEventListener('input', function(){
				var val = password.value;
				var result = zxcvbn(val);

				// Update the password strength meter
				meter.value = result.score;

				// Update the text indicator
				if(val !== "") {
					text.innerHTML = "Strength: " + "<strong>" + strength[result.score] + "</strong>" + "<span class='feedback'>" + result.feedback.warning + " " + result.feedback.suggestions + "</span"; 
				}
				else {
					text.innerHTML = "";
				}
				});
			</script>
		</div>
	<?php include('footer.php'); ?>
</body>
</html>
