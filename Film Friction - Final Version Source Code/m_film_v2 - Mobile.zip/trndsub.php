<?php
session_start();
		$store_email = $_REQUEST['em'];
		$visitor_email = 'subscribed@filmfriction.com';
		$to = $store_email;
		$subject='Film Friction - New and Trending Subscription';
		$from = $visitor_email;
		$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
		
		$body = '<html><body>';
		$body .= '
		<style>
		.estyle1 {
		  font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", "serif";
		  font-size: 16pt;
		} 
		</style>
		';	
			
		$body .= '	
		<table width="600" border="0">
		  <tbody>
			<tr>
			  <td><img src="http:www.filmfriction.com/emailheader.gif" width="600" height="347" alt=""/></td>
			</tr>
		  </tbody>
		</table>
		';
		$body .= '
		<table width="600" border="0">
		  <tbody>
			<tr> </tr>
			<tr>
			  <td class=estyle1>Thank you for subscribing to new and trending</td>
			</tr>';
		$body .= '			
			<tr>
			  <td>&nbsp;</td>
			</tr>
		   <tr>
			  <td class=estyle1>We will keep you updated with current news and content through our website</td>
			</tr>
			';
		$body .= '		
			<tr>
			  <td>&nbsp;</td>
			</tr>	  
			<tr>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td class=estyle1>Cheers,</td>
			</tr>';  
		$body .= '	
			<tr>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td>&nbsp;</td>
			</tr>			
			<tr>
			  <td class=estyle1>The Film Friction Team</td>
			</tr>'; 		 

		$body .= '<a href="http://www.filmfriction.com/trndunsub.php?id='; 
		$body .= $store_email;
		$body .= '">Click here to Unsubscribe</a>'; 
		$body .= '</a>'; 
		$body .= '</body></html>';		

		
		$headers = "From: $from \r\n";
		$headers .= "Reply-To: $visitor_email \r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		
		mail($to, $subject, $body, $headers);

		require_once "conninc.php";
		$exist = 0;
		
		$q2 = "SELECT * FROM trendsubscription WHERE email = '$store_email' ORDER BY id LIMIT 1";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {		
				$status=$row2["status"];
			    if ($status == 0) {
					$q4 = "UPDATE `trendsubscription` SET `status` = '1' WHERE `trendsubscription`.`email` = '$store_email'";
					$r4 = mysql_query($q4);
					echo mysql_error();		
					$exist = 1;
				}

				
				if ($status == 1) {
					$exist = 1;
				}
			}
		
		if ($exist != 1) {
			$q3 = "INSERT INTO trendsubscription (email, joindate) VALUES ('$store_email', NOW() )";       		
			$r3 = mysql_query($q3);
			echo mysql_error();
		}
		header('Location: index.php');	

?>

