<?php
require_once "conninc.php";
$trunk = "TRUNCATE TABLE `rssfanedit`";
	 mysql_query($trunk)or die (mysql_errno()."<br/>".mysql_error());



if (!ini_get('date.timezone')) {
	date_default_timezone_set('Europe/Prague');
}

if (!ini_get('date.timezone')) {
	date_default_timezone_set('Europe/Prague');
}

require_once 'src/Feed.php';


$atom = Feed::loadAtom('https://forums.fanedit.org/syndication.php?fid=&type=atom1.0&limit=30');

?>

<h1><?php echo htmlSpecialChars($atom->title) ?></h1>

<?php foreach ($atom->entry as $entry): ?>
	<h2><a href="<?php echo htmlSpecialChars($entry->link['href']) ?>"><?php echo htmlSpecialChars($entry->title) ?></a>
	<small><?php echo date("j.n.Y H:i", (int) $entry->timestamp) ?></small></h2>

	<?php if ($entry->content['type'] == 'html'): ?>
		<div><?php echo $entry->content ?></div>
	<?php else: ?>
		<p><?php echo htmlSpecialChars($entry->content) ?></p>
	<?php endif ?>
<?php endforeach ?>

<?php
  
  $sql = "INSERT INTO rssfanedit (`title`, `content`, `updated`, `link`, `rsid`) VALUES ('$title', '$content', '$updated', '$link', '$id')";

//		$result = mysql_query($sql);   
 endforeach 
 ?>




  