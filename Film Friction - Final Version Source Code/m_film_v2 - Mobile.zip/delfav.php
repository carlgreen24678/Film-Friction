<?php
		$store_user = $_REQUEST['us'];
		$store_film = $_REQUEST['fm'];
		$fav_exist = 0;
		require_once "conninc.php";

		$q1 = "DELETE FROM filmfavourite WHERE userid = $store_user && filmid = $store_film ";

        $r1 = mysql_query($q1);
      
	echo mysql_error();

		header('Location: film.php?f='.$store_film);	


?>
