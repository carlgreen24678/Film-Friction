
	<div class="f_userSettings">
       <input id="f_userName" type="hidden" placeholder="Username" value ="<?php echo $userName; ?>">
    </div>
    <div class="f_chat">
        <div id="f_chatOutput"></div>           
    <?php 
			if (isset($_SESSION['userName'])) {
			echo "<input id='f_chatInput' type='text' placeholder='Type here' maxlength='128'>";
			echo "<button id='f_chatSend'>Send</button>";
			}
	?>		
    </div>

