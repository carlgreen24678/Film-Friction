<?php
session_start();
if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
    $userid = $_SESSION['userID'];
	$userflag = 1;
	} 


	$catid = $_REQUEST['cat'];
	$checkid = $_REQUEST['id'];

if ($checkid != $userid && $checkid != '') { 
 echo '<META HTTP-EQUIV="Refresh" Content="0; URL=my-profile.php">';
}

?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>My Profile</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<link href="profile.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
<script>
function editname() {
  var txt;
  var person = prompt("Please enter your name:");
  var userid = "<?php echo $userid ?>";	
  if (person == null || person == "") {
    txt = "User cancelled the prompt.";
  } else {
	window.location = "editname.php?us=" + userid + "&name=" + person;  
  }
}
</script>		
		
		
	</head>
<body>
	<?php include('header.php');
		include('getuser.php');

	?>
	<div class="page-title">My Profile</div>
	<div class="profile-container">
		<div class="profile-img">
	<div class="img-holder" style="width:35%;">	
					<?php echo "<img src='images/profile/$avatar' height='200px' alt='' style='margin-left:20px; margin-top:20px;'/>"; ?>
				</div>
				
				<div class="img-button">				
				<form action="upload.php" method="post" enctype="multipart/form-data">  
				<input type="file" name="uploadedfile" class="photo_button" accept="image/*" capture >
				<input type="hidden" id="avid" name="avid" value="<?php echo $userid?>">			
				<input type="submit" class="submit_button" value="Upload">
				</div>
				</form>		
		</div>
		<div class="profile-info">
			<div class="profile-name">
				<?php echo $name . "  "; ?> <button onclick="editname()"  style="margin-left:50px;">Edit name</button>
			</div>
			<div class="profile-bio">
				<form action="writebio.php" method="get">
					<textarea name='bio' rows='15' style='width:100%' class=''><?php echo $bio; ?></textarea></td>
					  <input type="hidden" id="useid" name="useid" value="<?php echo $userid?>">
					<input type="submit" class = "biosubmit" style="cursor: pointer;" value="Update Bio">
				</form>	
			</div>
		</div>
		<!-- Playlist -->
		<button class="collapsible">Playlist</button>
		<div class="content">
			Insert content here...
		</div>
		<!-- History -->
		<button class="collapsible">History</button>
		<div class="content">
			Insert content here...
		</div>
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
				 coll[i].addEventListener("click", function() {
				this.classList.toggle("active");
				var content = this.nextElementSibling;
				if (content.style.display === "block") {
					 content.style.display = "none";
				} else {
					 content.style.display = "block";
				}
				});
			}
			</script>
	</div>
	<?php include('footer.php') ?>
</body>
</html>