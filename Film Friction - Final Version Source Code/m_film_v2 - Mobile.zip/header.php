<?php
if(isset($_POST['login']) AND $_POST['login'] != "")

{

$username = $_POST['username'];
$password = $_POST['password'];

require "conninc.php";


$q1 = "SELECT * FROM user WHERE username = '$username' && password = '$password' LIMIT 1";
	 $r1 = mysql_query($q1);	
while( $row1=mysql_fetch_array($r1)) {	
	$userid=$row1["id"];	
	$_SESSION["userName"] = $username;
	$_SESSION["userID"] = $userid;

}
echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
 
exit;

	
}
$username = "";
$password = "";

?>

<div id="header">
	<div class="logo-container">
		<a href="index.php"><img class="ff-logo" src="images/ff-mobile-logo.png" alt="Film Friction Logo"></a>
	</div>
	<div class="upper-header">
		<div class="ff-title-container">
			<h1 class="ff-title">Film Friction</h1>
		</div>
		<div class="menu" onclick="openNav()"></div>
	</div>
	<div class="lower-header">
		<div class="search">
			<input type="search" placeholder="Fan Edit?" class="searchbar">
		</div>
	</div>
</div>

<div id="myNav" class="overlay">
	<a href="javascript:void(0)" class="closebtn" onClick="closeNav()">&times;</a>
	<div class="overlay-content">
<?php
	if ($userflag == 0) {
		echo "<form name='register' method='post' class='login-form'>
			<p class='login-text' style='font-size: 18pt; color:#f2ae30'>Member Login</p>
			<p class='login-text'>Username</p>
			<input type='text' name='username' value='$username' required class='login-field'>
			<p class='login-text'>Password</p>
			<input type='password' name='password' value='$password' required class='login-field'>
			<input type='submit' name='login' value='Submit' class='reg-btn'>
 		</form>
			";
	}else {
		echo "	<a href='my-profile.php'>My Profile</a>";
	}	
?>			

		<a href="index.php">Home</a>
		<a href="about.php">About</a>
		<a href="new-and-trending.php">New and Trending</a>
		<a href="hall-of-fame.php">Hall of Fame</a>
		<a href="hall-of-shame.php">Hall of Shame</a>
		<a href="up-and-coming.php">Up and Coming</a>
		<a href="rss-feeds.php">RSS Feeds</a>
		<a href="contact.php">Contact Us</a>
<?php
if ($userflag == 1) {
		echo "<a href='logout.php'>Logout</a>";
	}else {
		echo "<a href='register.php'>Register</a>";
	}		
?>				
		
	</div>
</div>

<script>
	function openNav() {
		document.getElementById("myNav").style.width = "100%";
	}
	
	function closeNav() {
		document.getElementById("myNav").style.width = "0%";
	}
</script>