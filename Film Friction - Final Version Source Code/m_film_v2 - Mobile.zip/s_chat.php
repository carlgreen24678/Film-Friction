
	<div class="s_userSettings">
       <input id="s_userName" type="hidden" placeholder="Username" value ="<?php echo $userName; ?>">
    </div>
    <div class="s_chat">
        <div id="s_chatOutput"></div>           
    <?php 
			if (isset($_SESSION['userName'])) {
			echo "<input id='s_chatInput' type='text' placeholder='Type here' maxlength='128'>";
			echo "<button id='s_chatSend'>Send</button>";
			}
	?>		
    </div>

