<?php
require_once "conninc.php";

	$q2 = "SELECT * FROM shamechat ORDER BY id ASC";
	 
	$r2 = mysql_query($q2)or die($q2."<br/><br/>".mysql_error());
	while($row2=mysql_fetch_array($r2)) {
        $s_username=$row2["username"];
        $s_text=$row2["text"];
        $s_time=date('G:i', strtotime($row2["time"])); //outputs date as # #Hour#:#Minute#;

        echo "<p>$s_username: $s_text</p>\n";
    }

?>