<?php
require_once "conninc.php";

	$q2 = "SELECT * FROM trendchat ORDER BY id ASC";
	 
	$r2 = mysql_query($q2)or die($q2."<br/><br/>".mysql_error());
	while($row2=mysql_fetch_array($r2)) {
	
        $t_username=$row2["username"];
        $t_text=$row2["text"];
        $t_time=date('G:i', strtotime($row2["time"])); //outputs date as # #Hour#:#Minute#;

        echo "<p>$t_username: $t_text</p>\n";
    }

?>