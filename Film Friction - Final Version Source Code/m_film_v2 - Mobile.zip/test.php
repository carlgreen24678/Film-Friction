<html>
<body>
<script language="javaScript">
function writeToOpener(obj)
{
   opener.document.getElementById('thisTxtBox').value = obj.value;
}
</script>
<form method="POST">
    <p><input type="text" id="txtBox" size="20" onblur="writeToOpener(this)"></p>
</form>
</body>
</html>

Here is the code for the "main" window:

<html>
<body>
<script language="javascript">
function openWin()
{
   var newWin = open('C:\\pop.htm', 'myWin');
   var msg = newWin.document.getElementById('txtBox').value;
   document.getElementById('thisTxtBox').value = msg;
}
</script>
<p onclick="openWin()">CLICK HERE</p>
<p><input type="text" size="30" id="thisTxtBox">
</body>
</html>