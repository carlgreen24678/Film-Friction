
	<div class="c_userSettings">
       <input id="c_userName" type="hidden" placeholder="Username" value ="<?php echo $userName; ?>">
    </div>
    <div class="c_chat">
        <div id="c_chatOutput"></div>           
    <?php 
			if (isset($_SESSION['userName'])) {
			echo "<input id='c_chatInput' type='text' placeholder='Type here' maxlength='128'>";
			echo "<button id='c_chatSend'>Send</button>";
			}
	?>		
    </div>

