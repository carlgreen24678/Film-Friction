<?php
session_start();
$userflag = 0;

 if (isset($_SESSION['userName']))
	{
    $userName = $_SESSION['userName'];
	$userflag = 1;
	} 
	$store_subs = $_REQUEST['un'];
	$store_favs = $_REQUEST['fv'];
	
	?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<!-- content security for android -->
		<!-- look here: http://stackoverflow.com/questions/30212306/no-content-security-policy-meta-tag-found-error-in-my-phonegap-application -->
		<meta http-equiv="Content-Security-Policy" content="default-src * data: gap: https://ssl.gstatic.com 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src *; script-src * 'unsafe-inline';">
		<title>Film Friction</title>
		<link href="mainstyle.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="js/functions.js"></script>
		<script type="text/javascript" src="js/ff.js"></script>
			<script type="text/javascript">
		function trendsub(){
					var trsubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (trsubbal != null) {
						alert("Thank you for subscribing to New and Trending please check email address: " + trsubbal);
						window.location = "trndsub.php?em=" + trsubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
			</script>
			<script type="text/javascript">
					function famesub(){
					var famesubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (famesubbal != null) {
						alert("Thank you for subscribing to Hall of Fame please check email address: " + famesubbal);
						window.location = "famesub.php?em=" + famesubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
 
 
			 
			</script>
		<script type="text/javascript">
					function shamesub(){
					var shamesubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (shamesubbal != null) {
						alert("Thank you for subscribing to Hall of Shame please check email address: " + shamesubbal);
						window.location = "shamesub.php?em=" + shamesubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
 
 
			 
			</script>	
		<script type="text/javascript">
					function comingsub(){
					var comingsubbal = prompt("Please enter your email to subscribe!", "Email here");
 
					if (comingsubbal != null) {
						alert("Thank you for subscribing to Coming Soon please check email address: " + comingsubbal);
						window.location = "comingsub.php?em=" + comingsubbal;
					}
					else {
						alert ("We are sorry you chose not to subscribe!");
					}   
					}
 
 
			 
			</script>			
	</head>

	<body>
		<?php include('header.php'); ?>
		<div class="index-container">
			<div class="welcome">
				<p class="welcome-text">
					Welcome to Film Friction, where you can discover what fan edited versions of motion pictures exist.
				</p>
			</div>		
		</div>
<?php	
		include('fameshame.php');
			require_once "conninc.php";
			$count=0;
			$q2 = "SELECT * FROM films ORDER BY RAND() LIMIT 6";
			 
			$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
			while($row2=mysql_fetch_array($r2)) {
				$filmcover[$count]=$row2["background"];
				$filmid[$count]=$row2["id"];
				$filmname[$count]=$row2["name"];
				$count ++;
			}	

?>
			
		<!-- New and Trending Container -->
		<div class="content-container">
			<div class="container-title">
				<a href="new-and-trending.php">New and Trending</a>
			<a href="rss-feeds.php"><img src="images/rss-btn.png" style="justify-content: flex-end; width: 26%; height: 95%; border: none; border-radius: 5px; margin-left: 30%;"></a>
		 
			</div>
			<!-- Slideshow -->
			<div class="slideshow-container">
				<div class="mySlides1 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[0];
					echo '"><img alt="';
					echo $filmname[0];
					echo '" title="';
					echo $filmname[0];
					echo '"src="images/filmbackground/';
					echo $filmcover[0];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[0];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[0]; ?></div>
				</div>
				<div class="mySlides1 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[1];
					echo '"><img alt="';
					echo $filmname[1];
					echo '" title="';
					echo $filmname[1];
					echo '"src="images/filmbackground/';
					echo $filmcover[1];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[1];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[1]; ?></div>				
				</div>
				<div class="mySlides1 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[2];
					echo '"><img alt="';
					echo $filmname[2];
					echo '" title="';
					echo $filmname[2];
					echo '"src="images/filmbackground/';
					echo $filmcover[2];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[2];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[2]; ?></div>				
				</div>
				<a class="prev" onclick="plusSlides(-1, 0)">&#10094;</a>
				<a class="next" onclick="plusSlides(1, 0)">&#10095;</a>
			</div> 
		</div>
		
		<!-- Hall of Fame Container -->
<?php 		 
		 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE ORDER BY temp_filmaverage DESC LIMIT 3"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover[$famecount]=$row2["cover"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
						$famecount ++;
					}					

				}

?>				

		<div class="content-container">
			<div class="container-title">
				<a href="hall-of-fame.php">Hall of Fame</a>
				<a href="rss-feeds.php"><img src="images/rss-btn.png" style="justify-content: flex-end; width: 26%; height: 95%; border: none; border-radius: 5px; margin-left: 30%;"></a>
		 
			</div>
			<!-- Slideshow -->
			<div class="slideshow-container">
				<div class="mySlides2 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[2];
					echo '"><img alt="';
					echo $filmname[2];
					echo '" title="';
					echo $filmname[2];
					echo '"src="images/filmbackground/';
					echo $filmcover[2];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[2];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[2]; ?></div>				
				</div>
				<div class="mySlides2 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[1];
					echo '"><img alt="';
					echo $filmname[1];
					echo '" title="';
					echo $filmname[1];
					echo '"src="images/filmbackground/';
					echo $filmcover[1];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[1];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[1]; ?></div>				
				</div>
				<div class="mySlides2 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[0];
					echo '"><img alt="';
					echo $filmname[0];
					echo '" title="';
					echo $filmname[0];
					echo '"src="images/filmbackground/';
					echo $filmcover[0];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[0];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[0]; ?></div>				
				</div>
				<a class="prev" onclick="plusSlides(-1, 1)">&#10094;</a>
				<a class="next" onclick="plusSlides(1, 1)">&#10095;</a>
			</div>
		</div>
		
		<!-- Hall of Shame Container -->
<?php 		 
		 $famecount = 0;
		 $q3 = "SELECT * FROM TEMP_FAMESHAME_TABLE ORDER BY temp_filmaverage ASC LIMIT 3"; 
			$r3 = mysql_query($q3)or die($myQuery."<br/><br/>".mysql_error());
				while($row3=mysql_fetch_array($r3)) {				
					$t_filmid=$row3["temp_filmid"];
					$q2 = "SELECT * FROM films WHERE id = '$t_filmid' LIMIT 1";	 
					$r2 = mysql_query($q2)or die($myQuery."<br/><br/>".mysql_error());
					while($row2=mysql_fetch_array($r2)) {
						$f_filmcover[$famecount]=$row2["cover"];
						$f_filmid[$famecount]=$row2["id"];
						$f_filmname[$famecount]=$row2["name"];
						$famecount ++;
					}					

				}

?>			
		
		<div class="content-container">
			<div class="container-title">
				<a href="hall-of-shame.php">Hall of Shame</a>
				<a href="rss-feeds.php"><img src="images/rss-btn.png" style="justify-content: flex-end; width: 26%; height: 95%; border: none; border-radius: 5px; margin-left: 30%;"></a>
		 
			</div>
			<!-- Slideshow -->
			<div class="slideshow-container">
				<div class="mySlides3 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[0];
					echo '"><img alt="';
					echo $filmname[0];
					echo '" title="';
					echo $filmname[0];
					echo '"src="images/filmbackground/';
					echo $filmcover[0];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[0];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[0]; ?></div>				
				</div>
				<div class="mySlides3 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[1];
					echo '"><img alt="';
					echo $filmname[1];
					echo '" title="';
					echo $filmname[1];
					echo '"src="images/filmbackground/';
					echo $filmcover[1];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[1];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[1]; ?></div>				
				</div>
				<div class="mySlides3 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[2];
					echo '"><img alt="';
					echo $filmname[2];
					echo '" title="';
					echo $filmname[2];
					echo '"src="images/filmbackground/';
					echo $filmcover[2];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[2];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[2]; ?></div>				
				</div>
				<a class="prev" onclick="plusSlides1(-1, 0)">&#10094;</a>
				<a class="next" onclick="plusSlides1(1, 0)">&#10095;</a>
			</div>
		</div>
		
		<!-- Up and ComingContainer -->
		<div class="content-container">
			<div class="container-title">
				<a href="up-and-coming.php">Up and Coming</a>
				<a href="rss-feeds.php"><img src="images/rss-btn.png" style="justify-content: flex-end; width: 26%; height: 95%; border: none; border-radius: 5px; margin-left: 30%;"></a>
		 
			</div>
			<!-- Slideshow -->
			<div class="slideshow-container">
				<div class="mySlides4 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[3];
					echo '"><img alt="';
					echo $filmname[3];
					echo '" title="';
					echo $filmname[3];
					echo '"src="images/filmbackground/';
					echo $filmcover[3];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[3];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[3]; ?></div>				
				</div>
				<div class="mySlides4 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[4];
					echo '"><img alt="';
					echo $filmname[4];
					echo '" title="';
					echo $filmname[4];
					echo '"src="images/filmbackground/';
					echo $filmcover[4];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[4];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[4]; ?></div>				
				</div>
				<div class="mySlides4 fade">
<?php
					if (isset($_SESSION['userName'])) { 
					echo '<a href="film.php?f='; 
					echo $filmid[5];
					echo '"><img alt="';
					echo $filmname[5];
					echo '" title="';
					echo $filmname[5];
					echo '"src="images/filmbackground/';
					echo $filmcover[5];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%"></a>';
					}else {
					echo '<img alt="Login to view more details" title="Login to view more details"';
					echo ' src="images/filmbackground/';
					echo $filmcover[5];
					echo '" style="width: 95%;height: 230px; margin: 10px 2.5%">';
					}
				?>	
					<div class="text"><?php echo $filmname[5]; ?></div>				
				</div>
				<a class="prev" onclick="plusSlides1(-1, 1)">&#10094;</a>
				<a class="next" onclick="plusSlides1(1, 1)">&#10095;</a>
			</div>
		</div>
		
		<div class="content-container" style="height: auto">
			<div class="container-title" style="color: #f2ae30; font-family: PulpFiction; font-size: 18pt">Chat Feed</div>
			<div class="chat-container">
			
			</div>
		</div> 
		
		<!-- New and Trending/Hall of Fame - Slideshow script -->
		<script>
			var slideIndex = [1,1];
			var slideId = ["mySlides1", "mySlides2"]
			showSlides(1, 0);
			showSlides(1, 1);

			function plusSlides(n, no) {
			  showSlides(slideIndex[no] += n, no);
			}

			function showSlides(n, no) {
			  var i;
			  var x = document.getElementsByClassName(slideId[no]);
			  if (n > x.length) {slideIndex[no] = 1}    
			  if (n < 1) {slideIndex[no] = x.length}
			  for (i = 0; i < x.length; i++) {
				 x[i].style.display = "none";  
			  }
			  x[slideIndex[no]-1].style.display = "block";  
			}
		</script>
		<!-- Hall of Shame/Up and Coming - Slideshow script -->
		<script>
			var slideIndex1 = [1,1];
			var slideId1 = ["mySlides3", "mySlides4"]
			showSlides1(1, 0);
			showSlides1(1, 1);

			function plusSlides1(n1, no1) {
			  showSlides1(slideIndex1[no1] += n1, no1);
			}

			function showSlides1(n1, no1) {
			  var i1;
			  var x1 = document.getElementsByClassName(slideId1[no1]);
			  if (n1 > x1.length) {slideIndex1[no1] = 1}    
			  if (n1 < 1) {slideIndex1[no1] = x1.length}
			  for (i1 = 0; i1 < x1.length; i1++) {
				 x1[i1].style.display = "none";  
			  }
			  x1[slideIndex1[no1]-1].style.display = "block";  
			}
		</script>
		<?php include('footer.php'); ?>
	</body>
</html>
